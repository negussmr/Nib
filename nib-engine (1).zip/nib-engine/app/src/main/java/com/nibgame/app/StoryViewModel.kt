package com.nibgame.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nibgame.app.data.ContentRepo
import com.nibgame.app.data.UpdateResult
import com.nibgame.app.engine.Cast
import com.nibgame.app.engine.ChapterInfo
import com.nibgame.app.engine.ChapterProgress
import com.nibgame.app.engine.ChatItem
import com.nibgame.app.engine.Chapter
import com.nibgame.app.engine.Event
import com.nibgame.app.engine.SaveStore
import com.nibgame.app.engine.StoryEngine
import com.nibgame.app.engine.StoryParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

enum class Screen { Home, Chat }
enum class Status { Locked, New, InProgress, Done }

data class ChapterEntry(val info: ChapterInfo, val status: Status)

data class UiState(
    val screen: Screen = Screen.Home,
    val cast: Cast = Cast("", emptyMap()),
    val entries: List<ChapterEntry> = emptyList(),
    val notice: String? = null,
    val title: String = "",
    val items: List<ChatItem> = emptyList(),
    val typing: String? = null,       // id of the character who is "typing" right now
    val choices: List<String>? = null,
    val finished: Boolean = false,
)

/**
 * Plays chapters at a reading pace and keeps the save file in step with what is on screen.
 * There is deliberately no skip: the only things the player can do are read, scroll back, and choose.
 */
class StoryViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = ContentRepo(app)
    private val store = SaveStore(File(app.filesDir, "save.json"))
    private val saveQueue = Channel<com.nibgame.app.engine.SaveData>(Channel.CONFLATED)

    private var save = store.load()
    private var pack = repo.load()
    private var chapter: Chapter? = null
    private var engine: StoryEngine? = null
    private var playJob: Job? = null
    private var nextId = 1L
    private var checking = false

    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    init {
        // One writer, newest snapshot wins, so saves can never land out of order.
        viewModelScope.launch(Dispatchers.IO) {
            for (data in saveQueue) runCatching { store.write(data) }
        }
        refreshHome()
        checkForUpdates(force = false)
    }

    // ---- home -----------------------------------------------------------------------------

    private fun refreshHome() {
        var unlocked = true
        val entries = pack.manifest.chapters.map { info ->
            val p = save.chapters[info.id]
            val status = when {
                p?.done == true -> Status.Done
                !unlocked -> Status.Locked
                p != null && p.history.isNotEmpty() -> Status.InProgress
                else -> Status.New
            }
            if (p?.done != true) unlocked = false
            ChapterEntry(info, status)
        }
        _ui.update { it.copy(entries = entries, cast = pack.cast) }
    }

    fun checkForUpdates(force: Boolean) {
        if (!Config.updatesEnabled) {
            if (force) _ui.update { it.copy(notice = "Updates are off in this build.") }
            return
        }
        if (checking) return
        val now = System.currentTimeMillis()
        if (!force && now - save.lastCheckMs < Config.CHECK_INTERVAL_MS) return
        checking = true
        if (force) _ui.update { it.copy(notice = "Checking for new chapters…") }
        viewModelScope.launch {
            val result = repo.checkForUpdate()
            val notice: String? = when (result) {
                is UpdateResult.Updated -> {
                    pack = repo.load()
                    refreshHome()
                    if (result.newChapterTitles.isEmpty()) "Story pages refreshed."
                    else "New: " + result.newChapterTitles.joinToString(", ")
                }
                UpdateResult.UpToDate -> if (force) "You have every chapter." else null
                UpdateResult.NeedsAppUpdate -> "New chapters need the latest version of the app. Update it from the store."
                is UpdateResult.Failed -> if (force) "Couldn't reach the server. Check your connection and try again." else null
            }
            if (result is UpdateResult.Updated || result is UpdateResult.UpToDate) {
                save = save.copy(lastCheckMs = System.currentTimeMillis())
                saveQueue.trySend(save)
            }
            checking = false
            _ui.update { it.copy(notice = notice) }
        }
    }

    // ---- chat -----------------------------------------------------------------------------

    fun open(id: String) {
        val entry = _ui.value.entries.firstOrNull { it.info.id == id } ?: return
        if (entry.status == Status.Locked) return
        val ch = try {
            StoryParser.chapter(pack.read(entry.info.file))
        } catch (e: Exception) {
            _ui.update { it.copy(notice = "Couldn't open ${entry.info.title}: ${e.message}") }
            return
        }
        chapter = ch
        val progress = save.chapters[id]
        nextId = (progress?.history?.maxOfOrNull { it.id } ?: 0L) + 1
        engine = StoryEngine(ch, save.vars.toMutableMap(), progress?.pc ?: 0)
        _ui.update {
            it.copy(
                screen = Screen.Chat, title = ch.title, items = progress?.history ?: emptyList(),
                typing = null, choices = null, finished = progress?.done == true,
            )
        }
        if (progress?.done != true) play()
    }

    fun close() {
        playJob?.cancel()
        chapter = null
        engine = null
        _ui.update { it.copy(screen = Screen.Home, typing = null, choices = null, items = emptyList(), finished = false) }
        refreshHome()
    }

    fun choose(index: Int) {
        val eng = engine ?: return
        if (_ui.value.choices == null) return
        val said = try { eng.choose(index) } catch (e: Exception) { return }
        _ui.update { it.copy(choices = null) }
        add(ChatItem.Bubble(nextId++, pack.cast.player, said, mine = true))
        persist()
        play()
    }

    /** App left the screen: stop the story where the player last saw it. */
    fun pause() {
        if (playJob?.isActive == true) {
            playJob?.cancel()
            _ui.update { it.copy(typing = null) }
            // The engine already stepped past the message that was still "typing", so rewind to the last save.
            val ch = chapter
            if (ch != null) engine = StoryEngine(ch, save.vars.toMutableMap(), save.chapters[ch.id]?.pc ?: 0)
        }
        runCatching { store.write(save) }
    }

    fun resume() {
        val s = _ui.value
        if (s.screen == Screen.Chat && !s.finished && s.choices == null && playJob?.isActive != true) play()
    }

    private fun play() {
        playJob?.cancel()
        val eng = engine ?: return
        val player = pack.cast.player
        playJob = viewModelScope.launch {
            while (true) {
                when (val e = eng.advance()) {
                    is Event.Message -> {
                        val mine = e.who == player
                        if (mine) {
                            delay(Pacing.MINE_MS)
                        } else {
                            _ui.update { it.copy(typing = e.who) }
                            delay(Pacing.typing(e.text, e.typingMs))
                            _ui.update { it.copy(typing = null) }
                        }
                        add(ChatItem.Bubble(nextId++, e.who, e.text, mine))
                        persist()
                        delay(Pacing.beat(e.text))
                    }
                    is Event.Note -> {
                        delay(Pacing.NOTE_MS)
                        add(ChatItem.Note(nextId++, e.text))
                        persist()
                        delay(Pacing.NOTE_MS)
                    }
                    is Event.Pause -> {
                        delay(e.ms)
                        persist()
                    }
                    is Event.Reward -> {
                        delay(Pacing.NOTE_MS)
                        add(ChatItem.Card(nextId++, e.name, e.note))
                        persist()
                        delay(Pacing.NOTE_MS)
                    }
                    is Event.Choices -> {
                        _ui.update { it.copy(choices = e.texts) }
                        persist()
                        return@launch
                    }
                    Event.End -> {
                        _ui.update { it.copy(finished = true) }
                        persist()
                        return@launch
                    }
                }
            }
        }
    }

    private fun add(item: ChatItem) = _ui.update { it.copy(items = it.items + item) }

    private fun persist() {
        val id = chapter?.id ?: return
        val eng = engine ?: return
        val s = _ui.value
        save = save.copy(
            vars = eng.vars.toMap(),
            chapters = save.chapters + (id to ChapterProgress(eng.pc, s.finished, s.items)),
        )
        saveQueue.trySend(save)
    }

    override fun onCleared() {
        runCatching { store.write(save) }
    }
}
