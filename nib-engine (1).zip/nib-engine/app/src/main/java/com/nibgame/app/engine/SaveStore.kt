package com.nibgame.app.engine

import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class ChapterProgress(
    val pc: Int = 0,
    val done: Boolean = false,
    val history: List<ChatItem> = emptyList(),
)

data class SaveData(
    val vars: Map<String, Int> = emptyMap(),
    val chapters: Map<String, ChapterProgress> = emptyMap(),
    val lastCheckMs: Long = 0L,
)

/** Saves to one small JSON file. Writes go to a temp file first so a crash can't leave half a save. */
class SaveStore(private val file: File) {

    fun load(): SaveData {
        if (!file.exists()) return SaveData()
        return try {
            decode(file.readText())
        } catch (e: Exception) {
            runCatching { file.copyTo(File(file.path + ".bad"), overwrite = true) }
            SaveData()
        }
    }

    fun write(data: SaveData) {
        val tmp = File(file.path + ".tmp")
        tmp.writeText(encode(data))
        if (!tmp.renameTo(file)) {
            file.delete()
            tmp.renameTo(file)
        }
    }

    fun encode(d: SaveData): String {
        val root = JSONObject()
        root.put("lastCheck", d.lastCheckMs)
        val vars = JSONObject()
        d.vars.forEach { (k, v) -> vars.put(k, v) }
        root.put("vars", vars)
        val chapters = JSONObject()
        d.chapters.forEach { (id, p) ->
            val c = JSONObject()
            c.put("pc", p.pc)
            c.put("done", p.done)
            val h = JSONArray()
            p.history.forEach { h.put(item(it)) }
            c.put("history", h)
            chapters.put(id, c)
        }
        root.put("chapters", chapters)
        return root.toString()
    }

    fun decode(text: String): SaveData {
        val root = JSONObject(text)
        val vars = HashMap<String, Int>()
        root.optJSONObject("vars")?.let { v ->
            for (k in v.keys()) vars[k.toString()] = v.getInt(k.toString())
        }
        val chapters = HashMap<String, ChapterProgress>()
        root.optJSONObject("chapters")?.let { cs ->
            for (k in cs.keys()) {
                val id = k.toString()
                val c = cs.getJSONObject(id)
                val items = ArrayList<ChatItem>()
                val h = c.optJSONArray("history")
                if (h != null) for (i in 0 until h.length()) items.add(item(h.getJSONObject(i)))
                chapters[id] = ChapterProgress(c.optInt("pc", 0), c.optBoolean("done", false), items)
            }
        }
        return SaveData(vars, chapters, root.optLong("lastCheck", 0L))
    }

    private fun item(i: ChatItem): JSONObject {
        val o = JSONObject()
        when (i) {
            is ChatItem.Bubble -> { o.put("t", "b"); o.put("id", i.id); o.put("who", i.who); o.put("text", i.text); o.put("mine", i.mine) }
            is ChatItem.Note -> { o.put("t", "n"); o.put("id", i.id); o.put("text", i.text) }
            is ChatItem.Card -> { o.put("t", "c"); o.put("id", i.id); o.put("title", i.title); o.put("note", i.note) }
        }
        return o
    }

    private fun item(o: JSONObject): ChatItem = when (o.getString("t")) {
        "b" -> ChatItem.Bubble(o.getLong("id"), o.getString("who"), o.getString("text"), o.getBoolean("mine"))
        "n" -> ChatItem.Note(o.getLong("id"), o.getString("text"))
        else -> ChatItem.Card(o.getLong("id"), o.getString("title"), o.getString("note"))
    }
}
