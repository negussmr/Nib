package com.nibgame.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.unit.Dp
import com.nibgame.app.engine.Speaker

/**
 * Stickman portraits, drawn in code with a wobbly pen, so there is no art to produce or ship.
 * Silhouette is what tells characters apart: round head + scarf, round head + glasses,
 * angular head + spikes + sword, and a face scribbled out in red.
 * To add a character, add a case in drawAvatar and use its name as "avatar" in cast.json.
 */
@Composable
fun Avatar(speaker: Speaker?, size: Dp, modifier: Modifier = Modifier) {
    val kind = speaker?.avatar ?: "plain"
    val ink = Color(speaker?.ink ?: 0xFF1B2F8AL)
    val accent = Color(speaker?.accent ?: 0xFFD9362BL)
    val seed = (speaker?.id ?: "?").hashCode()
    Canvas(modifier.size(size)) { drawAvatar(kind, ink, accent, seed) }
}

private fun DrawScope.drawAvatar(kind: String, ink: Color, accent: Color, seed: Int) {
    val s = size.minDimension
    fun p(x: Float, y: Float) = Offset(x * s, y * s)
    val w = s * 0.05f
    val wob = s * 0.012f

    // the little paper disc
    drawCircle(Ink.bubble, radius = s * 0.48f, center = center)
    inkStroke(circlePts(center, s * 0.48f, 16), ink, w * 0.8f, seed, closed = true, wobble = wob)

    // shoulders
    inkStroke(listOf(p(.24f, .88f), p(.31f, .76f), p(.50f, .69f), p(.69f, .76f), p(.76f, .88f)), ink, w, seed + 1, wobble = wob)

    val roundHead = circlePts(p(.5f, .40f), s * .20f, 12)
    fun eyes(spread: Float = .07f) {
        drawCircle(ink, radius = s * .022f, center = p(.5f - spread, .40f))
        drawCircle(ink, radius = s * .022f, center = p(.5f + spread, .40f))
    }
    fun smile() = inkStroke(listOf(p(.45f, .49f), p(.50f, .505f), p(.55f, .49f)), ink, w * .7f, seed + 3, passes = 1, wobble = wob * .5f)

    when (kind) {
        "nib" -> {
            inkStroke(roundHead, ink, w, seed + 2, closed = true, wobble = wob)
            eyes(); smile()
            // red scarf with a tail, the one splash of colour
            inkStroke(listOf(p(.30f, .67f), p(.50f, .72f), p(.70f, .67f)), accent, w * 2.0f, seed + 4, passes = 1, wobble = wob * .6f)
            inkStroke(listOf(p(.62f, .71f), p(.67f, .81f), p(.63f, .90f)), accent, w * 1.7f, seed + 5, passes = 1, wobble = wob * .6f)
            // one stray curl of hair
            inkStroke(listOf(p(.48f, .21f), p(.52f, .11f), p(.61f, .12f), p(.58f, .19f)), ink, w, seed + 6, wobble = wob)
        }
        "pica" -> {
            inkStroke(roundHead, ink, w, seed + 2, closed = true, wobble = wob)
            inkStroke(circlePts(p(.5f, .15f), s * .065f, 8), ink, w, seed + 7, closed = true, wobble = wob) // hair bun
            inkStroke(circlePts(p(.41f, .40f), s * .052f, 8), accent, w * .9f, seed + 8, closed = true, wobble = wob * .6f)
            inkStroke(circlePts(p(.59f, .40f), s * .052f, 8), accent, w * .9f, seed + 9, closed = true, wobble = wob * .6f)
            inkStroke(listOf(p(.462f, .40f), p(.538f, .40f)), accent, w * .8f, seed + 10, passes = 1, wobble = 0f)
            eyes(.09f); smile()
        }
        "hatch" -> {
            // angular head, spiky hair, a scar and a sword over the shoulder
            inkStroke(listOf(p(.31f, .24f), p(.69f, .24f), p(.73f, .44f), p(.50f, .65f), p(.27f, .44f)), ink, w, seed + 2, closed = true, wobble = wob, sharp = true)
            inkStroke(listOf(p(.31f, .24f), p(.37f, .10f), p(.45f, .21f), p(.53f, .08f), p(.61f, .21f), p(.69f, .24f)), ink, w, seed + 3, wobble = wob, sharp = true)
            inkStroke(listOf(p(.38f, .41f), p(.46f, .43f)), ink, w * .9f, seed + 4, passes = 1, wobble = wob * .4f, sharp = true)
            inkStroke(listOf(p(.54f, .43f), p(.62f, .41f)), ink, w * .9f, seed + 5, passes = 1, wobble = wob * .4f, sharp = true)
            inkStroke(listOf(p(.58f, .29f), p(.63f, .43f)), accent, w * .8f, seed + 6, passes = 1, wobble = wob * .4f, sharp = true)
            inkStroke(listOf(p(.74f, .90f), p(.86f, .46f)), ink, w * 1.3f, seed + 7, wobble = wob, sharp = true)
            inkStroke(listOf(p(.79f, .60f), p(.91f, .55f)), ink, w, seed + 8, passes = 1, wobble = wob * .4f, sharp = true)
        }
        "mystery" -> {
            // a head that has been scribbled out with a red correction pen
            inkStroke(roundHead, Ink.graphite, w, seed + 2, closed = true, wobble = wob)
            val zigzag = (0..9).map { i -> p(.32f + .04f * i, if (i % 2 == 0) .29f else .51f) }
            inkStroke(zigzag, accent, w * .9f, seed + 3, wobble = wob, sharp = true)
            inkStroke(listOf(p(.34f, .27f), p(.66f, .53f)), accent, w * 1.3f, seed + 4, wobble = wob, sharp = true)
            inkStroke(listOf(p(.66f, .27f), p(.34f, .53f)), accent, w * 1.3f, seed + 5, wobble = wob, sharp = true)
        }
        else -> {
            inkStroke(roundHead, ink, w, seed + 2, closed = true, wobble = wob)
            eyes(); smile()
        }
    }
}
