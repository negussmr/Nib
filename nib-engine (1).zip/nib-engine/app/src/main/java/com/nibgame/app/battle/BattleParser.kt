package com.nibgame.app.battle

import com.nibgame.app.engine.StoryFormatException
import org.json.JSONException
import org.json.JSONObject

/** Reads battles.json. Like chapters, it is checked completely before the game will use it. */
object BattleParser {

    fun parse(json: String): BattleData {
        try {
            val root = JSONObject(json)
            val units = LinkedHashMap<String, UnitDef>()
            val ua = root.getJSONArray("units")
            for (i in 0 until ua.length()) {
                val u = unit(ua.getJSONObject(i))
                if (units.put(u.id, u) != null) throw StoryFormatException("battles.json: unit '${u.id}' is defined twice")
                check(u)
            }
            val battles = LinkedHashMap<String, BattleDef>()
            val ba = root.getJSONArray("battles")
            for (i in 0 until ba.length()) {
                val b = ba.getJSONObject(i)
                val def = BattleDef(
                    id = b.getString("id"),
                    title = b.optString("title", b.getString("id")),
                    allies = list(b, "allies"),
                    enemies = list(b, "enemies"),
                    startSp = b.optInt("startSp", 3),
                    maxSp = b.optInt("maxSp", 5),
                )
                if (def.allies.isEmpty() || def.allies.size > 4) throw StoryFormatException("battle '${def.id}' needs 1 to 4 allies")
                if (def.enemies.isEmpty() || def.enemies.size > 5) throw StoryFormatException("battle '${def.id}' needs 1 to 5 enemies")
                def.allies.forEach { if (units[it]?.side != Side.Ally) throw StoryFormatException("battle '${def.id}': '$it' is not an ally") }
                def.enemies.forEach { if (units[it]?.side != Side.Enemy) throw StoryFormatException("battle '${def.id}': '$it' is not an enemy") }
                battles[def.id] = def
            }
            return BattleData(units, battles)
        } catch (e: JSONException) {
            throw StoryFormatException("battles.json: ${e.message}")
        }
    }

    private fun list(o: JSONObject, key: String): List<String> {
        val a = o.getJSONArray(key)
        return (0 until a.length()).map { a.getString(it) }
    }

    private fun unit(o: JSONObject): UnitDef {
        val id = o.getString("id")
        val side = when (o.getString("side")) {
            "ally" -> Side.Ally
            "enemy" -> Side.Enemy
            else -> throw StoryFormatException("unit '$id': side must be ally or enemy")
        }
        val ma = o.getJSONArray("moves")
        val moves = LinkedHashMap<String, Move>()
        for (i in 0 until ma.length()) {
            val m = move(ma.getJSONObject(i), id)
            if (moves.put(m.id, m) != null) throw StoryFormatException("unit '$id': move '${m.id}' is defined twice")
        }
        return UnitDef(
            id = id, name = o.getString("name"), side = side, avatar = o.optString("avatar", "plain"),
            hp = o.getInt("hp"), atk = o.getInt("atk"), def = o.getInt("def"), spd = o.getInt("spd"),
            energyMax = o.optInt("energy", 0), moves = moves,
            basic = if (o.has("basic")) o.getString("basic") else null,
            skill = if (o.has("skill")) o.getString("skill") else null,
            ultimate = if (o.has("ultimate")) o.getString("ultimate") else null,
            pattern = if (o.has("pattern")) list(o, "pattern") else emptyList(),
        )
    }

    private fun move(o: JSONObject, owner: String): Move {
        val id = o.getString("id")
        val kind = when (o.getString("kind")) {
            "basic" -> Kind.Basic
            "skill" -> Kind.Skill
            "ultimate" -> Kind.Ultimate
            "enemy" -> Kind.Enemy
            else -> throw StoryFormatException("$owner.$id: kind must be basic, skill, ultimate or enemy")
        }
        val aim = when (o.getString("aim")) {
            "enemy" -> Aim.Enemy
            "blast" -> Aim.Blast
            "all_enemies" -> Aim.AllEnemies
            "ally" -> Aim.Ally
            "all_allies" -> Aim.AllAllies
            "self" -> Aim.Self
            else -> throw StoryFormatException("$owner.$id: unknown aim")
        }
        val ea = o.getJSONArray("effects")
        val effects = (0 until ea.length()).map { i ->
            val e = ea.getJSONObject(i)
            when (e.getString("type")) {
                "damage" -> Effect.Damage(e.getDouble("mult"))
                "heal" -> Effect.Heal(e.optDouble("mult", 0.0), e.optInt("flat", 0))
                "sp" -> Effect.GainSp(e.getInt("amount"))
                "atk_mod" -> Effect.AtkMod(e.getInt("pct"), e.getInt("turns"))
                else -> throw StoryFormatException("$owner.$id: unknown effect '${e.getString("type")}'")
            }
        }
        return Move(
            id = id, name = o.getString("name"), kind = kind, aim = aim,
            spCost = o.optInt("spCost", 0), spGain = o.optInt("spGain", 0), energy = o.optInt("energy", 0),
            splash = o.optDouble("splash", 0.5), effects = effects,
        )
    }

    private fun check(u: UnitDef) {
        fun need(id: String?, what: String) {
            if (id != null && id !in u.moves) throw StoryFormatException("unit '${u.id}': $what '$id' is not one of its moves")
        }
        if (u.hp <= 0 || u.spd <= 0) throw StoryFormatException("unit '${u.id}': hp and spd must be above 0")
        need(u.basic, "basic"); need(u.skill, "skill"); need(u.ultimate, "ultimate")
        u.pattern.forEach { need(it, "pattern move") }
        if (u.side == Side.Ally && u.basic == null) throw StoryFormatException("ally '${u.id}' needs a basic move")
        if (u.ultimate != null && u.energyMax <= 0) throw StoryFormatException("unit '${u.id}' has an ultimate but no energy bar")
        if (u.side == Side.Enemy && u.pattern.isEmpty()) throw StoryFormatException("enemy '${u.id}' needs a pattern of moves")
    }
}
