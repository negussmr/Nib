package com.nibgame.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nibgame.app.UiState
import com.nibgame.app.engine.Cast
import com.nibgame.app.engine.ChatItem
import com.nibgame.app.engine.Speaker
import kotlin.math.PI
import kotlin.math.sin

@Composable
fun ChatScreen(ui: UiState, onChoose: (Int) -> Unit, onBack: () -> Unit) {
    val state = rememberLazyListState(initialFirstVisibleItemIndex = (ui.items.size - 1).coerceAtLeast(0))
    val alreadyThere = remember { ui.items.size } // only messages that arrive while watching animate in
    val rows = ui.items.size + (if (ui.typing != null) 1 else 0) + (if (ui.finished) 1 else 0)

    // Follow the conversation, but don't yank the player back down if they scrolled up to reread.
    LaunchedEffect(ui.items.size, ui.typing, ui.finished, ui.choices) {
        if (rows == 0) return@LaunchedEffect
        val lastVisible = state.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: -1
        if (lastVisible >= rows - 3) state.animateScrollToItem(rows - 1)
    }

    Column(Modifier.fillMaxSize().notebook().statusBarsPadding().navigationBarsPadding()) {
        TopBar(ui.title, onBack)
        LazyColumn(
            state = state,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(top = 8.dp, bottom = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            itemsIndexed(ui.items, key = { _, item -> item.id }) { index, item ->
                ChatRow(item, ui.cast, isNew = index >= alreadyThere)
            }
            ui.typing?.let { id ->
                item(key = "typing") { TypingRow(ui.cast.speakers[id]) }
            }
            if (ui.finished) {
                item(key = "end") { EndRow(onBack) }
            }
        }
        AnimatedVisibility(visible = ui.choices != null, exit = ExitTransition.None) {
            ChoicePanel(ui.choices ?: emptyList(), onChoose)
        }
    }
}

@Composable
private fun TopBar(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(end = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Canvas(Modifier.size(52.dp).clickable(onClick = onBack).padding(15.dp)) {
            inkStroke(
                listOf(Offset(size.width * .7f, size.height * .1f), Offset(size.width * .25f, size.height * .5f), Offset(size.width * .7f, size.height * .9f)),
                Ink.blue, 2.4.dp.toPx(), 3, wobble = 0.7.dp.toPx(), sharp = true,
            )
        }
        Spacer(Modifier.width(3.dp))
        Text(title, style = hand(22))
    }
}

@Composable
private fun ChatRow(item: ChatItem, cast: Cast, isNew: Boolean) {
    when (item) {
        is ChatItem.Bubble -> BubbleRow(item, cast.speakers[item.who], isNew)
        is ChatItem.Note -> NoteRow(item, isNew)
        is ChatItem.Card -> CardRow(item, isNew)
    }
}

@Composable
private fun BubbleRow(b: ChatItem.Bubble, who: Speaker?, isNew: Boolean) {
    val ink = if (who != null) Color(who.ink) else Ink.blue
    val seed = b.id.toInt()
    if (b.mine) {
        Row(
            Modifier.fillMaxWidth().padding(start = TextStart, end = 12.dp).popIn(isNew),
            horizontalArrangement = Arrangement.End,
        ) {
            Box(Modifier.widthIn(max = 280.dp).sketchBox(seed, Ink.highlighter, Ink.blue, width = 2.dp).padding(horizontal = 14.dp, vertical = 9.dp)) {
                Text(b.text, style = hand(18, Ink.blue))
            }
        }
    } else {
        Row(Modifier.fillMaxWidth().padding(start = 7.dp, end = 12.dp).popIn(isNew), verticalAlignment = Alignment.Top) {
            Avatar(who, 40.dp)
            Spacer(Modifier.width(15.dp))
            Column(Modifier.widthIn(max = 280.dp)) {
                Text(who?.name ?: b.who, style = hand(14, Ink.graphite), modifier = Modifier.padding(start = 6.dp, bottom = 1.dp))
                Box(Modifier.sketchBox(seed, Ink.bubble, ink).padding(horizontal = 14.dp, vertical = 9.dp)) {
                    Text(b.text, style = hand(18, ink))
                }
            }
        }
    }
}

@Composable
private fun NoteRow(n: ChatItem.Note, isNew: Boolean) {
    Box(
        Modifier.fillMaxWidth().padding(start = TextStart, end = 12.dp).popIn(isNew),
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.sketchBox(n.id.toInt(), Color.Transparent, Ink.graphite, radius = 6.dp, width = 1.dp).padding(horizontal = 14.dp, vertical = 8.dp)) {
            Text(n.text, style = hand(15, Ink.graphite).copy(textAlign = TextAlign.Center))
        }
    }
}

@Composable
private fun CardRow(c: ChatItem.Card, isNew: Boolean) {
    Box(
        Modifier.fillMaxWidth().padding(start = TextStart, end = 12.dp).popIn(isNew),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier.rotate(-1.5f).sketchBox(c.id.toInt(), Ink.bubble, Ink.red, radius = 8.dp, width = 2.4.dp)
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("Picked up", style = hand(14, Ink.red))
            Text(c.title, style = hand(22))
            Text(c.note, style = hand(14, Ink.graphite))
        }
    }
}

@Composable
private fun TypingRow(who: Speaker?) {
    val ink = if (who != null) Color(who.ink) else Ink.blue
    Row(Modifier.fillMaxWidth().padding(start = 7.dp), verticalAlignment = Alignment.Bottom) {
        Avatar(who, 40.dp)
        Spacer(Modifier.width(15.dp))
        TypingBubble(who?.id.hashCode(), ink)
    }
}

@Composable
private fun TypingBubble(seed: Int, ink: Color) {
    val transition = rememberInfiniteTransition(label = "dots")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1000, easing = LinearEasing)),
        label = "phase",
    )
    Box(Modifier.size(width = 62.dp, height = 36.dp).sketchBox(seed, Ink.bubble, ink), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(width = 36.dp, height = 14.dp)) {
            for (i in 0..2) {
                val bounce = sin(phase * 2f * PI.toFloat() - i * 0.9f)
                drawCircle(
                    ink, radius = 3.dp.toPx(),
                    center = Offset(size.width * (0.14f + 0.36f * i), size.height / 2f - bounce * 3.dp.toPx()),
                )
            }
        }
    }
}

@Composable
private fun EndRow(onBack: () -> Unit) {
    Box(Modifier.fillMaxWidth().padding(start = TextStart, end = 12.dp, top = 8.dp), contentAlignment = Alignment.Center) {
        Box(
            Modifier.sketchBox(99, Ink.highlighter, Ink.blue, width = 2.dp).clickable(onClick = onBack)
                .padding(horizontal = 22.dp, vertical = 11.dp),
        ) { Text("Back to chapters", style = hand(18)) }
    }
}

@Composable
private fun ChoicePanel(texts: List<String>, onPick: (Int) -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(start = TextStart, end = 12.dp, top = 10.dp, bottom = 10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        texts.forEachIndexed { i, text ->
            Box(
                Modifier.fillMaxWidth().sketchBox(text.hashCode(), Ink.bubble, Ink.blue, width = 2.2.dp)
                    .clickable { onPick(i) }.padding(horizontal = 16.dp, vertical = 12.dp),
            ) { Text(text, style = hand(18)) }
        }
    }
}

/** New messages ease in; anything already on screen when the chapter opened does not. */
@Composable
private fun Modifier.popIn(enabled: Boolean): Modifier {
    val progress = remember { Animatable(if (enabled) 0f else 1f) }
    LaunchedEffect(Unit) { if (enabled) progress.animateTo(1f, tween(200)) }
    return this.graphicsLayer {
        alpha = progress.value
        translationY = (1f - progress.value) * 10.dp.toPx()
    }
}
