package com.nibgame.app.ui

import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nibgame.app.R
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * The look: a school notebook. Cool lined paper, a red margin line, ballpoint pens.
 * Each character has their own pen colour, so who is talking is visible before you read a name.
 */
object Ink {
    val page = Color(0xFFF1F5F8)
    val rule = Color(0xFFBCD2E8)
    val margin = Color(0xFFE0605A)
    val bubble = Color(0xFFFFFFFF)
    val highlighter = Color(0xFFFFEB6B)
    val graphite = Color(0xFF666B73)
    val blue = Color(0xFF1B2F8A)
    val red = Color(0xFFC8322A)
}

/** Where the red margin line sits. Avatars live to its left, messages to its right. */
val MarginX = 54.dp
val TextStart = 62.dp

val Handlee = FontFamily(Font(R.font.handlee))

fun hand(size: Int, color: Color = Ink.blue) =
    TextStyle(fontFamily = Handlee, fontSize = size.sp, lineHeight = (size * 1.3f).sp, color = color)

// ---- pen-line drawing ---------------------------------------------------------------------

fun jitter(pts: List<Offset>, amount: Float, seed: Int): List<Offset> {
    val r = Random(seed)
    return pts.map { Offset(it.x + (r.nextFloat() - 0.5f) * 2f * amount, it.y + (r.nextFloat() - 0.5f) * 2f * amount) }
}

/** A smooth curve through the points (Catmull-Rom turned into cubic curves). */
fun smoothPath(pts: List<Offset>, closed: Boolean): Path {
    val path = Path()
    val n = pts.size
    if (n < 2) return path
    fun at(i: Int): Offset = if (closed) pts[((i % n) + n) % n] else pts[i.coerceIn(0, n - 1)]
    path.moveTo(pts[0].x, pts[0].y)
    val segments = if (closed) n else n - 1
    for (i in 0 until segments) {
        val p0 = at(i - 1)
        val p1 = at(i)
        val p2 = at(i + 1)
        val p3 = at(i + 2)
        val c1 = p1 + (p2 - p0) / 6f
        val c2 = p2 - (p3 - p1) / 6f
        path.cubicTo(c1.x, c1.y, c2.x, c2.y, p2.x, p2.y)
    }
    if (closed) path.close()
    return path
}

fun sharpPath(pts: List<Offset>, closed: Boolean): Path {
    val path = Path()
    if (pts.isEmpty()) return path
    path.moveTo(pts[0].x, pts[0].y)
    for (i in 1 until pts.size) path.lineTo(pts[i].x, pts[i].y)
    if (closed) path.close()
    return path
}

/** Draws a line the way a pen would: wobbly, and gone over twice. */
fun DrawScope.inkStroke(
    pts: List<Offset>,
    color: Color,
    width: Float,
    seed: Int,
    closed: Boolean = false,
    wobble: Float = 1.2f,
    passes: Int = 2,
    sharp: Boolean = false,
) {
    repeat(passes) { k ->
        val j = jitter(pts, wobble, seed * 31 + k * 7 + 1)
        drawPath(
            path = if (sharp) sharpPath(j, closed) else smoothPath(j, closed),
            color = color,
            alpha = if (k == 0) 1f else 0.5f,
            style = Stroke(width = if (k == 0) width else width * 0.7f, cap = StrokeCap.Round, join = StrokeJoin.Round),
        )
    }
}

fun circlePts(center: Offset, r: Float, n: Int): List<Offset> =
    (0 until n).map {
        val a = 2.0 * PI * it / n
        Offset(center.x + r * cos(a).toFloat(), center.y + r * sin(a).toFloat())
    }

private fun roundRectPoints(w: Float, h: Float, r: Float, step: Float): List<Offset> {
    val pts = ArrayList<Offset>()
    fun line(x0: Float, y0: Float, x1: Float, y1: Float) {
        val n = max(1, (hypot(x1 - x0, y1 - y0) / step).toInt())
        for (i in 0 until n) {
            val t = i / n.toFloat()
            pts.add(Offset(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t))
        }
    }
    fun arc(cx: Float, cy: Float, startDeg: Float) {
        val n = 4
        for (i in 0 until n) {
            val a = Math.toRadians(startDeg + 90.0 * i / n)
            pts.add(Offset(cx + r * cos(a).toFloat(), cy + r * sin(a).toFloat()))
        }
    }
    line(r, 0f, w - r, 0f)
    arc(w - r, r, -90f)
    line(w, r, w, h - r)
    arc(w - r, h - r, 0f)
    line(w - r, h, r, h)
    arc(r, h - r, 90f)
    line(0f, h - r, 0f, r)
    arc(r, r, 180f)
    return pts
}

/** A hand-drawn rounded box behind whatever it wraps. Same seed = same wobble every time. */
fun Modifier.sketchBox(
    seed: Int,
    fill: Color,
    line: Color = Ink.blue,
    radius: Dp = 14.dp,
    width: Dp = 1.8.dp,
): Modifier = drawBehind {
    val inset = 3.dp.toPx()
    val w = size.width - inset * 2
    val h = size.height - inset * 2
    if (w <= 0f || h <= 0f) return@drawBehind
    val r = min(radius.toPx(), min(w, h) / 2.2f)
    val base = roundRectPoints(w, h, r, 14.dp.toPx()).map { it + Offset(inset, inset) }
    val wobble = 1.1.dp.toPx()
    val outline = jitter(base, wobble, seed)
    val stroke = width.toPx()
    if (fill != Color.Transparent) drawPath(smoothPath(outline, true), color = fill)
    drawPath(
        smoothPath(outline, true), color = line,
        style = Stroke(width = stroke, cap = StrokeCap.Round, join = StrokeJoin.Round),
    )
    drawPath(
        smoothPath(jitter(base, wobble, seed + 1), true), color = line, alpha = 0.45f,
        style = Stroke(width = stroke * 0.7f, cap = StrokeCap.Round, join = StrokeJoin.Round),
    )
}

/** Lined paper with a red margin. Draw it once, behind a whole screen. */
fun Modifier.notebook(): Modifier = drawBehind {
    drawRect(Ink.page)
    val gap = 30.dp.toPx()
    var y = gap
    while (y < size.height) {
        drawLine(Ink.rule, Offset(0f, y), Offset(size.width, y), strokeWidth = 1.dp.toPx())
        y += gap
    }
    val x = MarginX.toPx()
    drawLine(Ink.margin, Offset(x, 0f), Offset(x, size.height), strokeWidth = 1.5.dp.toPx())
}
