package com.nibgame.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.unit.dp
import com.nibgame.app.ChapterEntry
import com.nibgame.app.Config
import com.nibgame.app.Status
import com.nibgame.app.UiState

@Composable
fun HomeScreen(ui: UiState, onOpen: (String) -> Unit, onCheck: () -> Unit) {
    Column(Modifier.fillMaxSize().notebook().statusBarsPadding().navigationBarsPadding()) {
        Box(Modifier.fillMaxWidth()) {
            Avatar(ui.cast.speakers[ui.cast.player], 40.dp, Modifier.padding(start = 7.dp, top = 38.dp))
            Column(Modifier.padding(start = TextStart, end = 16.dp, top = 28.dp, bottom = 14.dp)) {
                Text(Config.GAME_TITLE, style = hand(52))
                ui.notice?.let { Text(it, style = hand(16, Ink.red), modifier = Modifier.padding(top = 6.dp)) }
            }
        }
        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(start = TextStart, end = 16.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            itemsIndexed(ui.entries, key = { _, e -> e.info.id }) { index, entry ->
                ChapterCard(index + 1, entry, onOpen)
            }
        }
        Text(
            "Check for new chapters",
            style = hand(16, Ink.graphite),
            modifier = Modifier.clickable(onClick = onCheck).padding(start = TextStart, end = 16.dp, top = 12.dp, bottom = 18.dp),
        )
    }
}

@Composable
private fun ChapterCard(number: Int, entry: ChapterEntry, onOpen: (String) -> Unit) {
    val locked = entry.status == Status.Locked
    val note = when (entry.status) {
        Status.Locked -> "Finish the chapter before this one"
        Status.New -> "New"
        Status.InProgress -> "Keep reading"
        Status.Done -> "Read. Tap to look back"
    }
    Column(
        Modifier.fillMaxWidth().alpha(if (locked) 0.5f else 1f)
            .sketchBox(entry.info.id.hashCode(), Ink.bubble, Ink.blue, width = 2.dp)
            .clickable(enabled = !locked) { onOpen(entry.info.id) }
            .padding(horizontal = 18.dp, vertical = 14.dp),
    ) {
        Text("Chapter $number", style = hand(14, Ink.graphite))
        Text(entry.info.title, style = hand(24))
        Text(note, style = hand(15, if (entry.status == Status.New) Ink.red else Ink.graphite))
    }
}
