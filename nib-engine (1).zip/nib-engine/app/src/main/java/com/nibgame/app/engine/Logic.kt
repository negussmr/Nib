package com.nibgame.app.engine

/**
 * Conditions: "trust>=2", "met_pica", "!drew", or several joined with &&.
 * A bare name means "is not 0". Unset variables are 0.
 */
object Cond {
    private val term = Regex("""^(!)?\s*([A-Za-z_]\w*)\s*(?:(==|!=|>=|<=|>|<)\s*(-?\d+))?$""")

    fun check(expr: String) {
        expr.split("&&").forEach {
            term.matchEntire(it.trim()) ?: throw StoryFormatException("Bad condition '$expr'")
        }
    }

    fun eval(expr: String?, vars: Map<String, Int>): Boolean {
        if (expr.isNullOrBlank()) return true
        return expr.split("&&").all { raw ->
            val m = term.matchEntire(raw.trim()) ?: throw StoryFormatException("Bad condition '$expr'")
            val v = vars[m.groupValues[2]] ?: 0
            val op = m.groupValues[3]
            val ok = if (op.isEmpty()) {
                v != 0
            } else {
                val n = m.groupValues[4].toInt()
                when (op) {
                    "==" -> v == n
                    "!=" -> v != n
                    ">=" -> v >= n
                    "<=" -> v <= n
                    ">" -> v > n
                    else -> v < n
                }
            }
            if (m.groupValues[1] == "!") !ok else ok
        }
    }
}

/** Changes to variables: "met_pica=1", "trust+=1", "gold-=5". */
object Ops {
    private val op = Regex("""^\s*([A-Za-z_]\w*)\s*(\+=|-=|=)\s*(-?\d+)\s*$""")

    fun check(expr: String) {
        op.matchEntire(expr) ?: throw StoryFormatException("Bad set '$expr' (use name=1, name+=1 or name-=1)")
    }

    fun apply(expr: String, vars: MutableMap<String, Int>) {
        val m = op.matchEntire(expr) ?: throw StoryFormatException("Bad set '$expr'")
        val name = m.groupValues[1]
        val n = m.groupValues[3].toInt()
        val old = vars[name] ?: 0
        vars[name] = when (m.groupValues[2]) {
            "=" -> n
            "+=" -> old + n
            else -> old - n
        }
    }
}
