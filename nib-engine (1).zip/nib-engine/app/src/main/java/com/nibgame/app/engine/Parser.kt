package com.nibgame.app.engine

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/** Turns the JSON files into objects, and rejects anything broken with a message that says where. */
object StoryParser {

    private inline fun <T> guard(what: String, block: () -> T): T =
        try {
            block()
        } catch (e: JSONException) {
            throw StoryFormatException("$what: ${e.message}")
        }

    private val safeName = Regex("""^[A-Za-z0-9_-]+\.json$""")

    /** File names come from the internet, so only plain names like ch02.json are allowed (no folders, no "..").  */
    private fun safe(name: String): String {
        if (!safeName.matches(name)) throw StoryFormatException("Unsafe file name '$name' in manifest.json")
        return name
    }

    fun manifest(json: String): Manifest = guard("manifest.json") {
        val o = JSONObject(json)
        val list = o.getJSONArray("chapters")
        Manifest(
            version = o.getInt("version"),
            schema = o.optInt("schema", 1),
            cast = safe(o.optString("cast", "cast.json")),
            chapters = (0 until list.length()).map { i ->
                val c = list.getJSONObject(i)
                ChapterInfo(c.getString("id"), safe(c.getString("file")), c.getString("title"), c.optInt("rev", 1))
            },
        )
    }

    fun cast(json: String): Cast = guard("cast.json") {
        val o = JSONObject(json)
        val arr = o.getJSONArray("characters")
        val map = LinkedHashMap<String, Speaker>()
        for (i in 0 until arr.length()) {
            val c = arr.getJSONObject(i)
            val id = c.getString("id")
            val ink = color(c.optString("ink", "#1B2F8A"))
            map[id] = Speaker(id, c.getString("name"), c.optString("avatar", "plain"), ink, color(c.optString("accent", "#D9362B")))
        }
        Cast(o.getString("player"), map)
    }

    fun chapter(json: String): Chapter {
        val o = guard("chapter") { JSONObject(json) }
        val id = guard("chapter") { o.getString("id") }
        val arr = guard("chapter $id") { o.getJSONArray("steps") }
        val steps = (0 until arr.length()).map { i ->
            try {
                step(arr.getJSONObject(i), "$id step ${i + 1}")
            } catch (e: JSONException) {
                throw StoryFormatException("$id step ${i + 1}: ${e.message}")
            }
        }
        val ch = Chapter(id, guard("chapter $id") { o.getString("title") }, steps)
        validate(ch)
        return ch
    }

    private fun step(o: JSONObject, at: String): Step = when {
        o.has("say") -> Step.Say(o.getString("say"), o.getString("text"), if (o.has("typing")) o.getLong("typing") else null)
        o.has("narr") -> Step.Narr(o.getString("narr"))
        o.has("choice") -> {
            val a = o.getJSONArray("choice")
            Step.Choice(
                (0 until a.length()).map { j ->
                    val c = a.getJSONObject(j)
                    Opt(
                        text = c.getString("text"),
                        goto = if (c.has("goto")) c.getString("goto") else null,
                        set = strings(c, "set"),
                        cond = if (c.has("if")) c.getString("if") else null,
                        once = c.optBoolean("once", false),
                    )
                },
            )
        }
        o.has("if") -> Step.If(o.getString("if"), o.getString("goto"))
        o.has("goto") -> Step.Goto(o.getString("goto"))
        o.has("label") -> Step.Label(o.getString("label"))
        o.has("set") -> Step.SetVars(strings(o, "set"))
        o.has("wait") -> Step.Wait(o.getLong("wait"))
        o.has("give") -> Step.Give(o.getString("give"), o.optString("name", o.getString("give")), o.optString("note", ""))
        o.has("end") -> Step.End
        else -> throw StoryFormatException("$at: unknown step (keys: ${o.keys().asSequence().joinToString()})")
    }

    private fun strings(o: JSONObject, key: String): List<String> {
        if (!o.has(key)) return emptyList()
        val v = o.get(key)
        return if (v is JSONArray) (0 until v.length()).map { v.getString(it) } else listOf(v.toString())
    }

    private fun color(s: String): Long {
        val h = s.removePrefix("#")
        val v = h.toLongOrNull(16) ?: throw StoryFormatException("Bad colour '$s'")
        return if (h.length <= 6) 0xFF000000L or v else v
    }

    /** Catches typos in labels, conditions and sets before a chapter can reach a player. */
    private fun validate(ch: Chapter) {
        val seen = HashSet<String>()
        fun target(label: String, where: String) {
            if (!ch.hasLabel(label)) throw StoryFormatException("${ch.id} $where: jumps to missing label '$label'")
        }
        ch.steps.forEachIndexed { i, s ->
            val where = "step ${i + 1}"
            when (s) {
                is Step.Label -> if (!seen.add(s.name)) throw StoryFormatException("${ch.id}: label '${s.name}' is defined twice")
                is Step.Goto -> target(s.label, where)
                is Step.If -> { Cond.check(s.cond); target(s.label, where) }
                is Step.SetVars -> s.ops.forEach { Ops.check(it) }
                is Step.Choice -> {
                    if (s.options.isEmpty()) throw StoryFormatException("${ch.id} $where: choice has no options")
                    s.options.forEach { o ->
                        o.goto?.let { target(it, "$where (choice)") }
                        o.cond?.let { Cond.check(it) }
                        o.set.forEach { Ops.check(it) }
                    }
                }
                else -> Unit
            }
        }
    }
}
