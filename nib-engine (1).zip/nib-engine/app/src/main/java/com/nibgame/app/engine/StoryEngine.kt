package com.nibgame.app.engine

/**
 * Runs one chapter. It knows nothing about screens or timing: ask for the next [Event],
 * show it however you like, and (after a [Event.Choices]) call [choose].
 *
 * State is just [pc] + [vars], so saving and resuming is trivial. Asking for the next event
 * while a choice is waiting simply returns the same choice again.
 */
class StoryEngine(
    val chapter: Chapter,
    val vars: MutableMap<String, Int> = mutableMapOf(),
    startPc: Int = 0,
) {
    var pc: Int = startPc.coerceIn(0, chapter.steps.size)
        private set

    private var pending: List<Pair<Int, Opt>>? = null

    fun advance(): Event {
        pending = null
        var silentSteps = 0
        while (true) {
            if (++silentSteps > MAX_SILENT_STEPS) {
                throw StoryFormatException("Chapter '${chapter.id}' loops forever without showing anything near step ${pc + 1}")
            }
            if (pc >= chapter.steps.size) return Event.End
            when (val s = chapter.steps[pc]) {
                is Step.Label -> pc++
                is Step.Goto -> pc = chapter.labelIndex(s.label)
                is Step.SetVars -> { s.ops.forEach { Ops.apply(it, vars) }; pc++ }
                is Step.If -> pc = if (Cond.eval(s.cond, vars)) chapter.labelIndex(s.label) else pc + 1
                is Step.Say -> { pc++; return Event.Message(s.who, s.text, s.typingMs) }
                is Step.Narr -> { pc++; return Event.Note(s.text) }
                is Step.Wait -> { pc++; return Event.Pause(s.ms) }
                is Step.Give -> { vars["has_${s.itemId}"] = 1; pc++; return Event.Reward(s.itemId, s.name, s.note) }
                Step.End -> return Event.End
                is Step.Choice -> {
                    val visible = s.options.withIndex()
                        .filter { (i, o) -> Cond.eval(o.cond, vars) && !(o.once && vars[onceKey(i)] == 1) }
                        .map { it.index to it.value }
                    if (visible.isEmpty()) {
                        pc++
                    } else {
                        pending = visible
                        return Event.Choices(visible.map { it.second.text })
                    }
                }
            }
        }
    }

    /** Pick one of the texts from the last [Event.Choices]. Returns what the player "said". */
    fun choose(visibleIndex: Int): String {
        val list = pending ?: throw IllegalStateException("No choice is waiting")
        val (original, opt) = list[visibleIndex]
        if (opt.once) vars[onceKey(original)] = 1
        opt.set.forEach { Ops.apply(it, vars) }
        pending = null
        pc = if (opt.goto != null) chapter.labelIndex(opt.goto) else pc + 1
        return opt.text
    }

    private fun onceKey(optionIndex: Int) = "_once_${chapter.id}_${pc}_$optionIndex"

    companion object {
        private const val MAX_SILENT_STEPS = 10_000
    }
}
