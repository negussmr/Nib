package com.nibgame.app

object Config {
    const val GAME_TITLE = "Nib"

    /**
     * The GitHub folder that holds manifest.json, cast.json and the chapters.
     * The GitHub build replaces YOUR_REPO with your real "name/repo" automatically.
     * Must end with "/". While it still says YOUR_REPO the app skips update checks.
     */
    const val CONTENT_BASE_URL = "https://raw.githubusercontent.com/YOUR_REPO/main/content/"

    /** How often opening the app triggers a look for new chapters. */
    const val CHECK_INTERVAL_MS = 12L * 60 * 60 * 1000

    val updatesEnabled: Boolean get() = !CONTENT_BASE_URL.contains("YOUR_REPO")
}

/** Reading pace. There is no skip, so these numbers are the whole feel of the story. */
object Pacing {
    fun typing(text: String, override: Long?): Long = override ?: (400L + text.length * 18L).coerceIn(600L, 2400L)
    fun beat(text: String): Long = (250L + text.length * 8L).coerceIn(300L, 1200L)
    const val NOTE_MS = 600L
    const val MINE_MS = 350L
}
