#!/usr/bin/env bash
# Runs inside GitHub Actions. Builds the APK, publishes it as a release, and writes a summary
# you can read (and copy) on your phone.
set -uo pipefail
cd "$(dirname "$0")/.."
SUMMARY="${GITHUB_STEP_SUMMARY:-/dev/null}"
REPO="${GITHUB_REPOSITORY:-}"
BRANCH="${GITHUB_REF_NAME:-main}"
CONFIG=app/src/main/java/com/nibgame/app/Config.kt

# Point the in-app update checker at this repo's content/ folder.
if [ -n "$REPO" ]; then
  sed -i "s#YOUR_REPO#${REPO}#; s#/main/content/#/${BRANCH}/content/#" "$CONFIG"
fi

# Story files in the repo's content/ folder are what the app downloads for updates.
# On the first build, copy the bundled ones there so there is something to edit.
if [ -n "$REPO" ] && [ -n "${GITHUB_WORKSPACE:-}" ] && [ ! -f "$GITHUB_WORKSPACE/content/manifest.json" ]; then
  mkdir -p "$GITHUB_WORKSPACE/content"
  cp app/src/main/assets/content/*.json "$GITHUB_WORKSPACE/content/"
  (
    cd "$GITHUB_WORKSPACE" &&
    git config user.name "nib-build" &&
    git config user.email "nib-build@users.noreply.github.com" &&
    git add content &&
    git commit -q -m "Add story files for in-app updates" &&
    git push -q
  ) || echo "Could not add content/ automatically (not fatal)."
fi

if command -v sdkmanager >/dev/null 2>&1; then
  yes | sdkmanager --licenses >/dev/null 2>&1 || true
  sdkmanager "platforms;android-36" "build-tools;35.0.0" >/dev/null 2>&1 || true
fi

gradle --no-daemon --console=plain :app:assembleDebug 2>&1 | tee build.log
STATUS=${PIPESTATUS[0]}

if [ "$STATUS" -ne 0 ]; then
  {
    echo "## Build failed"
    echo
    echo "Copy everything in the box below and send it to Claude."
    echo
    echo '```'
    {
      grep -E '^e: ' build.log | sed -E 's#^e: file://.*/app/src/main/(java|kotlin)/com/nibgame/app/#e: #' | sort -u | head -40
      grep -E 'AAPT|error:' build.log | head -10
      sed -n '/What went wrong/,/^\* Try/p' build.log | head -14
    } | cut -c1-260
    echo '```'
  } >> "$SUMMARY"
  exit "$STATUS"
fi

APK="$(find app/build/outputs/apk/debug -name '*.apk' | head -1)"
cp "$APK" nib-debug.apk
echo "Built $(du -h nib-debug.apk | cut -f1) APK"

if [ -n "$REPO" ]; then
  TAG="build-${GITHUB_RUN_NUMBER:-0}"
  gh release create "$TAG" nib-debug.apk \
    --repo "$REPO" --target "${GITHUB_SHA:-$BRANCH}" \
    --title "Nib build ${GITHUB_RUN_NUMBER:-0}" \
    --notes "Test build. Tap nib-debug.apk below to install on your phone."
  # Keep only the five newest build releases.
  gh release list --repo "$REPO" --limit 100 --json tagName --jq '.[].tagName' \
    | grep '^build-' | tail -n +6 \
    | while read -r old; do gh release delete "$old" --repo "$REPO" --cleanup-tag --yes || true; done
  {
    echo "## Build ${GITHUB_RUN_NUMBER:-0} is ready"
    echo
    echo "Open this page and tap nib-debug.apk to install:"
    echo
    echo "https://github.com/${REPO}/releases/tag/${TAG}"
  } >> "$SUMMARY"
fi
