package com.nibgame.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nibgame.app.BattleUi
import com.nibgame.app.FighterUi
import com.nibgame.app.MoveUi
import com.nibgame.app.UiState
import com.nibgame.app.battle.Outcome
import com.nibgame.app.battle.Side
import com.nibgame.app.engine.Cast
import kotlin.math.min
import kotlin.math.roundToInt

@Composable
fun BattleScreen(
    ui: UiState,
    onMove: (String) -> Unit,
    onUlt: (String) -> Unit,
    onTarget: (String) -> Unit,
    onCancel: () -> Unit,
    onContinue: () -> Unit,
    onRetry: () -> Unit,
    onLeave: () -> Unit,
) {
    val b = ui.battle ?: return
    Column(Modifier.fillMaxSize().notebook().statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(start = TextStart, end = 14.dp, top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(b.title, style = hand(22), modifier = Modifier.weight(1f))
            SkillPoints(b.sp, b.maxSp)
        }
        TurnStrip(b, ui.cast)
        Row(Modifier.fillMaxWidth().weight(1f).padding(start = TextStart, end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            b.enemies.forEach { f -> Box(Modifier.weight(1f), contentAlignment = Alignment.Center) { EnemyView(f, b, onTarget) } }
        }
        Row(Modifier.fillMaxWidth().weight(1f).padding(start = TextStart, end = 6.dp), verticalAlignment = Alignment.Bottom) {
            b.allies.forEach { f -> Box(Modifier.weight(1f), contentAlignment = Alignment.BottomCenter) { AllyView(f, b, ui.cast, onTarget) } }
        }
        Column(Modifier.fillMaxWidth().padding(start = TextStart, end = 12.dp, top = 6.dp, bottom = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                if (b.selecting) "Tap a target. Tap a move again to cancel." else b.log,
                style = hand(15, Ink.graphite),
                modifier = Modifier.clickable(enabled = b.selecting, onClick = onCancel),
            )
            when (b.outcome) {
                Outcome.Won -> BigButton("Continue", onContinue)
                Outcome.Lost -> {
                    BigButton("Try again", onRetry)
                    Text("Leave the fight", style = hand(16, Ink.graphite), modifier = Modifier.clickable(onClick = onLeave).padding(8.dp))
                }
                null -> {
                    if (b.moves.isNotEmpty()) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            b.moves.forEach { m -> MoveButton(m, Modifier.weight(1f), highlight = false) { onMove(m.id) } }
                        }
                    }
                    if (b.ults.isNotEmpty()) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            b.ults.forEach { u -> MoveButton(u, Modifier.weight(1f), highlight = true) { onUlt(u.id) } }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SkillPoints(sp: Int, max: Int) {
    Canvas(Modifier.size(width = (max * 20).dp, height = 20.dp)) {
        for (i in 0 until max) {
            val c = Offset(size.height / 2 + i * 20.dp.toPx(), size.height / 2)
            val r = 7.dp.toPx()
            val filled = i < sp
            inkStroke(circlePts(c, r, 10), if (filled) Ink.blue else Ink.graphite, 1.5.dp.toPx(), 70 + i, closed = true, wobble = 0.5.dp.toPx(), passes = 1)
            if (filled) drawCircle(Ink.blue, radius = r * .6f, center = c)
        }
    }
}

@Composable
private fun TurnStrip(b: BattleUi, cast: Cast) {
    val all = b.allies + b.enemies
    Row(
        Modifier.fillMaxWidth().padding(start = TextStart, end = 8.dp, top = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        b.order.forEachIndexed { i, uid ->
            val f = all.firstOrNull { it.uid == uid } ?: return@forEachIndexed
            val sz = if (i == 0) 34.dp else 26.dp
            val frame = if (i == 0) Modifier.sketchBox(uid.hashCode(), Ink.highlighter, Ink.blue, radius = 8.dp, width = 1.4.dp) else Modifier
            Box(Modifier.size(sz + 6.dp).then(frame), contentAlignment = Alignment.Center) {
                if (f.side == Side.Ally) {
                    Avatar(cast.speakers[f.id], sz)
                } else {
                    Canvas(Modifier.size(sz)) { drawEnemy(f.avatar, size.width / 2, size.height / 2, size.minDimension * .95f, uid.hashCode()) }
                }
            }
        }
    }
}

@Composable
private fun EnemyView(f: FighterUi, b: BattleUi, onTarget: (String) -> Unit) {
    val targetable = f.uid in b.targetUids
    Column(
        Modifier.fillMaxWidth().alpha(if (f.alive) 1f else .25f).clickable(enabled = targetable) { onTarget(f.uid) }.padding(vertical = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(68.dp), contentAlignment = Alignment.TopCenter) {
            Canvas(Modifier.size(68.dp)) {
                if (targetable) {
                    inkStroke(circlePts(center, size.minDimension * .5f, 14), Ink.red, 2.2.dp.toPx(), f.uid.hashCode(), closed = true, wobble = 1.5.dp.toPx())
                }
                drawEnemy(f.avatar, center.x, center.y, size.minDimension * .8f, f.uid.hashCode())
            }
            FloatText(f.uid, b)
        }
        HpBar(f.hp, f.maxHp, f.shield, Ink.red)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            PathBadge(f.path, 18.dp)
            MatchupArrow(f.matchup)
        }
    }
}

@Composable
private fun AllyView(f: FighterUi, b: BattleUi, cast: Cast, onTarget: (String) -> Unit) {
    val speaker = cast.speakers[f.id]
    val ink = Color(speaker?.ink ?: 0xFF1B2F8AL)
    val accent = Color(speaker?.accent ?: 0xFFD9362BL)
    val targetable = f.uid in b.targetUids
    val active = f.uid == b.currentUid && b.outcome == null
    Column(
        Modifier.fillMaxWidth().alpha(if (f.alive) 1f else .25f).clickable(enabled = targetable) { onTarget(f.uid) },
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.fillMaxWidth().height(100.dp), contentAlignment = Alignment.TopCenter) {
            Canvas(Modifier.fillMaxSize()) {
                val foot = size.height - 8.dp.toPx()
                if (active) {
                    drawRect(Ink.highlighter, topLeft = Offset(size.width * .12f, foot + 2.dp.toPx()), size = Size(size.width * .76f, 5.dp.toPx()))
                }
                if (targetable) {
                    inkStroke(circlePts(Offset(size.width / 2, size.height * .5f), size.height * .48f, 14), Ink.red, 2.dp.toPx(), f.uid.hashCode(), closed = true, wobble = 1.5.dp.toPx())
                }
                drawFigure(f.avatar, ink, accent, f.uid.hashCode(), size.width / 2, foot, size.height * .88f)
            }
            FloatText(f.uid, b)
        }
        Text(f.name, style = hand(13, ink))
        HpBar(f.hp, f.maxHp, f.shield, ink)
        EnergyPips(f.energy, f.energyMax, ink)
        PathBadge(f.path, 18.dp)
    }
}

@Composable
private fun FloatText(uid: String, b: BattleUi) {
    val fl = b.floaters.firstOrNull { it.uid == uid } ?: return
    val color = when (fl.kind) {
        1 -> Color(0xFF2E7D32)
        2 -> Color(0xFF0A7FA8)
        3 -> Ink.graphite
        else -> Ink.red
    }
    Text(fl.text, style = hand(if (fl.kind == 4) 32 else 24, color))
}

@Composable
private fun HpBar(hp: Int, max: Int, shield: Int, color: Color) {
    Canvas(Modifier.fillMaxWidth().height(12.dp).padding(horizontal = 6.dp)) {
        val y = size.height / 2
        inkStroke(listOf(Offset(0f, y), Offset(size.width, y)), Ink.graphite, 1.4.dp.toPx(), 5, passes = 1, wobble = .4.dp.toPx())
        val frac = if (max > 0) (hp.toFloat() / max).coerceIn(0f, 1f) else 0f
        if (frac > 0f) inkStroke(listOf(Offset(0f, y), Offset(size.width * frac, y)), color, 3.dp.toPx(), 6, passes = 1, wobble = .4.dp.toPx())
        if (shield > 0 && max > 0) {
            val sf = min(1f, shield.toFloat() / max)
            inkStroke(listOf(Offset(0f, y - 4.dp.toPx()), Offset(size.width * sf, y - 4.dp.toPx())), Color(0xFF0A7FA8), 2.dp.toPx(), 7, passes = 1, wobble = .3.dp.toPx())
        }
    }
}

@Composable
private fun EnergyPips(energy: Int, max: Int, color: Color) {
    if (max <= 0) return
    val filled = ((energy.toFloat() / max) * 5f).roundToInt()
    Canvas(Modifier.size(width = 50.dp, height = 10.dp)) {
        for (i in 0 until 5) {
            val c = Offset(5.dp.toPx() + i * 10.dp.toPx(), size.height / 2)
            if (i < filled) drawCircle(color, radius = 3.dp.toPx(), center = c)
            else inkStroke(circlePts(c, 3.dp.toPx(), 8), Ink.graphite, 1.dp.toPx(), 9 + i, closed = true, wobble = .2.dp.toPx(), passes = 1)
        }
    }
}

@Composable
private fun MoveButton(m: MoveUi, modifier: Modifier, highlight: Boolean, onClick: () -> Unit) {
    Column(
        modifier.alpha(if (m.enabled) 1f else .4f)
            .sketchBox(m.id.hashCode(), if (highlight) Ink.highlighter else Ink.bubble, if (highlight) Ink.red else Ink.blue, width = 2.dp)
            .clickable(enabled = m.enabled, onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 9.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(m.name, style = hand(16).copy(textAlign = TextAlign.Center))
        if (m.sub.isNotEmpty()) Text(m.sub, style = hand(12, Ink.graphite).copy(textAlign = TextAlign.Center))
    }
}

@Composable
private fun BigButton(text: String, onClick: () -> Unit) {
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Box(
            Modifier.sketchBox(text.hashCode(), Ink.highlighter, Ink.blue, width = 2.dp).clickable(onClick = onClick)
                .padding(horizontal = 28.dp, vertical = 12.dp),
        ) { Text(text, style = hand(20)) }
    }
}
