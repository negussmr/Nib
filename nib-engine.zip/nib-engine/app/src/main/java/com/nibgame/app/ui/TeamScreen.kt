package com.nibgame.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.unit.dp
import com.nibgame.app.UiState
import com.nibgame.app.battle.Side
import com.nibgame.app.battle.UnitDef
import com.nibgame.app.gacha.Fragment
import com.nibgame.app.gacha.withCopies

@Composable
fun TeamScreen(ui: UiState, onToggle: (String) -> Unit) {
    val p = ui.profile
    val heroes = ui.units.values.filter { it.side == Side.Ally }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = TextStart, end = 14.dp, top = 4.dp, bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item { Text("Party: ${p.party.size} of 4. Tap a hero to add or remove them.", style = hand(15, Ink.graphite)) }
        items(heroes, key = { it.id }) { u -> HeroRow(u, ui, onToggle) }
        if (p.fragments.isNotEmpty()) {
            item {
                Text(
                    "Sketch Fragments. Equipping them arrives in the next update.",
                    style = hand(15, Ink.graphite), modifier = Modifier.padding(top = 8.dp),
                )
            }
            items(p.fragments.reversed(), key = { it.id }) { f -> FragmentRow(f) }
        }
    }
}

@Composable
private fun HeroRow(u: UnitDef, ui: UiState, onToggle: (String) -> Unit) {
    val p = ui.profile
    val owned = p.owned.containsKey(u.id)
    val copies = p.owned[u.id] ?: 0
    val inParty = u.id in p.party
    val s = u.withCopies(copies)
    Row(
        Modifier.fillMaxWidth().alpha(if (owned) 1f else .45f)
            .sketchBox(u.id.hashCode(), Ink.bubble, if (inParty) Ink.red else Ink.blue, width = 2.dp)
            .clickable(enabled = owned) { onToggle(u.id) }
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Avatar(ui.cast.speakers[u.id], 46.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(u.name, style = hand(20))
                Spacer(Modifier.width(6.dp))
                PathBadge(u.path, 20.dp)
                if (copies > 0) Text("  +$copies", style = hand(15, Ink.red))
            }
            Text(
                if (owned) "HP ${s.hp}  ATK ${s.atk}  DEF ${s.def}  SPD ${s.spd}" else "Not found yet. Try the call-up.",
                style = hand(13, Ink.graphite),
            )
        }
        if (owned) Text(if (inParty) "In party" else "Add", style = hand(15, if (inParty) Ink.red else Ink.graphite))
    }
}

@Composable
private fun FragmentRow(f: Fragment) {
    Column(Modifier.fillMaxWidth().sketchBox(f.id.toInt(), Ink.bubble, Ink.graphite, radius = 8.dp, width = 1.4.dp).padding(horizontal = 12.dp, vertical = 8.dp)) {
        Text(f.name, style = hand(17))
        Text("${f.slot.name} fragment, +${f.pct}% ${f.stat.name}", style = hand(13, Ink.graphite))
    }
}
