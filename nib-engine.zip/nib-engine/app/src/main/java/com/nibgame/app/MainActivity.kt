package com.nibgame.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.nibgame.app.ui.BattleScreen
import com.nibgame.app.ui.ChatScreen
import com.nibgame.app.ui.HomeScreen

class MainActivity : ComponentActivity() {

    private val vm: StoryViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // The paper is always light, so keep the system bar icons dark even in dark mode.
        val clear = android.graphics.Color.TRANSPARENT
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(clear, clear),
            navigationBarStyle = SystemBarStyle.light(clear, clear),
        )
        setContent {
            val ui by vm.ui.collectAsState()
            BackHandler(enabled = ui.screen != Screen.Home) {
                if (ui.screen == Screen.Battle) vm.battleLeave() else vm.close()
            }
            MaterialTheme {
                when (ui.screen) {
                    Screen.Home -> HomeScreen(
                        ui,
                        onOpen = vm::open,
                        onCheck = { vm.checkForUpdates(force = true) },
                        onTab = vm::setTab,
                        onToggle = vm::toggleParty,
                        onPull = vm::pull,
                        onCloseDrops = vm::closeDrops,
                    )
                    Screen.Chat -> ChatScreen(ui, onChoose = vm::choose, onBack = vm::close)
                    Screen.Battle -> BattleScreen(
                        ui,
                        onMove = vm::battleMove,
                        onUlt = vm::battleUltimate,
                        onTarget = vm::battleTarget,
                        onCancel = vm::battleCancelSelect,
                        onContinue = vm::battleContinue,
                        onRetry = vm::battleRetry,
                        onLeave = vm::battleLeave,
                    )
                }
            }
        }
    }

    // The story only moves while the app is on screen.
    override fun onStart() { super.onStart(); vm.resume() }
    override fun onStop() { super.onStop(); vm.pause() }
}
