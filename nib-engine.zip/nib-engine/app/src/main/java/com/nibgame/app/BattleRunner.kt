package com.nibgame.app

import com.nibgame.app.battle.BEvent
import com.nibgame.app.battle.Battle
import com.nibgame.app.battle.BattleDef
import com.nibgame.app.battle.Fighter
import com.nibgame.app.battle.Matchups
import com.nibgame.app.battle.Move
import com.nibgame.app.battle.Outcome
import com.nibgame.app.battle.Path
import com.nibgame.app.battle.Side
import com.nibgame.app.battle.UnitDef
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Everything the battle screen needs to draw, as plain data. */
data class FighterUi(
    val uid: String, val id: String, val name: String, val avatar: String, val path: Path?, val side: Side,
    val hp: Int, val maxHp: Int, val shield: Int, val energy: Int, val energyMax: Int, val alive: Boolean,
    val matchup: Int,          // for enemies: +1 if the fighter whose turn it is has the edge, -1 if not
)

data class MoveUi(val id: String, val name: String, val sub: String, val enabled: Boolean)

/** kind: 0 damage, 1 heal, 2 shield, 3 hit on a weak matchup, 4 hit on a strong matchup */
data class Floater(val uid: String, val text: String, val kind: Int)

data class BattleUi(
    val title: String, val sp: Int, val maxSp: Int,
    val allies: List<FighterUi>, val enemies: List<FighterUi>,
    val order: List<String>, val currentUid: String?, val myTurn: Boolean,
    val moves: List<MoveUi>, val ults: List<MoveUi>,
    val selecting: Boolean, val targetUids: Set<String>,
    val log: String, val floaters: List<Floater>, val outcome: Outcome?,
)

/** Plays one fight at a readable pace: enemies act on their own, the player picks moves and targets. */
class BattleRunner(
    private val scope: CoroutineScope,
    private val def: BattleDef,
    units: Map<String, UnitDef>,
    seed: Int,
    private val publish: (BattleUi) -> Unit,
) {
    private val battle = Battle(def, units, seed)
    private var job: Job? = null
    private var selecting: String? = null      // "m:<move id>" or "u:<fighter uid>"
    private var busy = true
    private var log = ""
    private var floaters: List<Floater> = emptyList()

    fun start() = advance()
    fun cancel() { job?.cancel() }

    // ---- what the player can do -------------------------------------------------------------

    fun chooseMove(id: String) {
        val cur = battle.current ?: return
        if (busy || cur.side != Side.Ally || battle.options().none { it.id == id }) return
        val move = cur.def.moves.getValue(id)
        val targets = battle.targets(move, cur)
        when {
            targets.isEmpty() -> act(move, null)
            targets.size == 1 -> act(move, targets[0])
            else -> { selecting = "m:$id"; push() }
        }
    }

    fun chooseUltimate(uid: String) {
        if (busy) return
        val f = battle.fighter(uid)
        if (f !in battle.ultimates()) return
        val move = f.def.moves.getValue(f.def.ultimate!!)
        val targets = battle.targets(move, f)
        when {
            targets.isEmpty() -> ultimate(f, null)
            targets.size == 1 -> ultimate(f, targets[0])
            else -> { selecting = "u:$uid"; push() }
        }
    }

    fun chooseTarget(uid: String) {
        val sel = selecting ?: return
        if (busy) return
        val target = battle.fighter(uid)
        if (sel.startsWith("m:")) {
            val cur = battle.current ?: return
            val move = cur.def.moves[sel.removePrefix("m:")] ?: return
            if (target in battle.targets(move, cur)) act(move, target)
        } else {
            val f = battle.fighter(sel.removePrefix("u:"))
            val move = f.def.moves.getValue(f.def.ultimate!!)
            if (f in battle.ultimates() && target in battle.targets(move, f)) ultimate(f, target)
        }
    }

    fun cancelSelect() { selecting = null; push() }

    // ---- turn flow --------------------------------------------------------------------------

    private fun advance() {
        job?.cancel()
        job = scope.launch {
            while (true) {
                val who = battle.nextTurn() ?: break
                if (who.side == Side.Enemy) {
                    busy = true; log = "${who.def.name} moves…"; push()
                    delay(700)
                    play(battle.enemyTurn(), who)
                    if (battle.outcome != null) break
                } else {
                    busy = false; selecting = null; log = "${who.def.name}'s turn"; push()
                    return@launch
                }
            }
            busy = false; finishLog(); push()
        }
    }

    private fun act(move: Move, target: Fighter?) {
        val actor = battle.current ?: return
        busy = true; selecting = null
        job?.cancel()
        job = scope.launch {
            try { play(battle.act(move, target), actor) } catch (e: IllegalStateException) { busy = false; push(); return@launch }
            if (battle.outcome != null) { busy = false; finishLog(); push() } else advance()
        }
    }

    private fun ultimate(caster: Fighter, target: Fighter?) {
        busy = true; selecting = null
        job?.cancel()
        job = scope.launch {
            try { play(battle.ultimate(caster, target), caster) } catch (e: IllegalStateException) { busy = false; push(); return@launch }
            busy = false
            if (battle.outcome != null) finishLog() else log = "${battle.current?.def?.name ?: ""}'s turn"
            push()
        }
    }

    private suspend fun play(events: List<BEvent>, actor: Fighter) {
        for (e in events) {
            when (e) {
                is BEvent.Used -> { log = "${actor.def.name} uses ${e.move}"; push(); delay(350) }
                is BEvent.Hit -> { floaters = listOf(Floater(e.target, "${e.amount}", if (e.matchup > 0) 4 else if (e.matchup < 0) 3 else 0)); push(); delay(450) }
                is BEvent.Healed -> { floaters = listOf(Floater(e.target, "+${e.amount}", 1)); push(); delay(450) }
                is BEvent.Shielded -> { floaters = listOf(Floater(e.target, "+${e.amount}", 2)); push(); delay(450) }
                is BEvent.Modded -> { log = "${battle.fighter(e.target).def.name} ATK ${if (e.pct > 0) "+" else ""}${e.pct}%"; push(); delay(250) }
                is BEvent.Down -> { log = "${battle.fighter(e.target).def.name} is erased"; push(); delay(300) }
                else -> Unit
            }
            floaters = emptyList()
        }
        push()
    }

    private fun finishLog() { log = if (battle.outcome == Outcome.Won) "The page holds." else "The white wins this one." }

    // ---- snapshot ---------------------------------------------------------------------------

    private fun push() = publish(snapshot())

    fun snapshot(): BattleUi {
        val cur = battle.current
        fun fu(f: Fighter) = FighterUi(
            f.uid, f.def.id, f.def.name, f.def.avatar, f.def.path, f.side, f.hp, f.def.hp, f.shield, f.energy, f.def.energyMax, f.alive,
            matchup = if (cur != null && cur.side == Side.Ally && f.side == Side.Enemy) Matchups.versus(cur.def.path, f.def.path) else 0,
        )
        val myTurn = !busy && cur?.side == Side.Ally && battle.outcome == null
        val available = if (myTurn) battle.options().map { it.id }.toSet() else emptySet()
        val moves = if (myTurn && cur != null) {
            listOfNotNull(cur.def.basic, cur.def.skill).map { id ->
                val m = cur.def.moves.getValue(id)
                MoveUi(id, m.name, sub(m), id in available)
            }
        } else emptyList()
        val ults = if (myTurn) battle.ultimates().map { f ->
            MoveUi(f.uid, f.def.moves.getValue(f.def.ultimate!!).name, f.def.name, true)
        } else emptyList()
        val sel = selecting
        val targetUids: Set<String> = when {
            sel == null || busy -> emptySet()
            sel.startsWith("m:") && cur != null -> cur.def.moves[sel.removePrefix("m:")]?.let { m -> battle.targets(m, cur).map { it.uid }.toSet() } ?: emptySet()
            sel.startsWith("u:") -> {
                val f = battle.fighter(sel.removePrefix("u:"))
                battle.targets(f.def.moves.getValue(f.def.ultimate!!), f).map { it.uid }.toSet()
            }
            else -> emptySet()
        }
        return BattleUi(
            title = def.title, sp = battle.sp, maxSp = def.maxSp,
            allies = battle.allies.map(::fu), enemies = battle.enemies.map(::fu),
            order = battle.upcoming(7).map { it.uid }, currentUid = cur?.uid, myTurn = myTurn,
            moves = moves, ults = ults, selecting = sel != null, targetUids = targetUids,
            log = log, floaters = floaters, outcome = battle.outcome,
        )
    }

    private fun sub(m: Move): String = when {
        m.spGain > 0 -> "+${m.spGain} skill point"
        m.spCost > 0 -> "costs ${m.spCost} skill point"
        else -> ""
    }
}
