package com.nibgame.app.battle

import kotlin.math.max
import kotlin.math.roundToInt

enum class Side { Ally, Enemy }

/** The 8 paths. C, M, Y, K are the four Printers' inks. The other four are ways of undoing a mark. */
enum class Path(val key: String, val badge: String) {
    C("c", "C"), M("m", "M"), Y("y", "Y"), K("k", "K"),
    Eraser("eraser", "Er"), Correction("correction", "Co"), Friction("friction", "Fr"), Scribble("scribble", "Sc");

    companion object {
        fun fromKey(key: String): Path? = entries.firstOrNull { it.key == key }
    }
}

/** Every path beats two others (x1.5 damage) and loses to two (x0.75). */
object Matchups {
    const val STRONG = 1.5
    const val WEAK = 0.75
    private val beats: Map<Path, Set<Path>> = mapOf(
        Path.C to setOf(Path.Eraser, Path.M),
        Path.Eraser to setOf(Path.M, Path.Correction),
        Path.M to setOf(Path.Correction, Path.Y),
        Path.Correction to setOf(Path.Y, Path.Friction),
        Path.Y to setOf(Path.Friction, Path.K),
        Path.Friction to setOf(Path.K, Path.Scribble),
        Path.K to setOf(Path.Scribble, Path.C),
        Path.Scribble to setOf(Path.C, Path.Eraser),
    )

    fun beats(a: Path): Set<Path> = beats.getValue(a)

    /** +1 if the attacker has the advantage, -1 if the target does, otherwise 0. */
    fun versus(attacker: Path?, target: Path?): Int = when {
        attacker == null || target == null -> 0
        target in beats.getValue(attacker) -> 1
        attacker in beats.getValue(target) -> -1
        else -> 0
    }

    fun multiplier(matchup: Int): Double = when (matchup) { 1 -> STRONG; -1 -> WEAK; else -> 1.0 }
}

/** Basic = free move that earns a skill point. Skill = costs one. Ultimate = needs a full energy bar. */
enum class Kind { Basic, Skill, Ultimate, Enemy }

/** Who a move hits. "Enemy" and "Ally" are from the user's point of view, so for an enemy's move "enemy" means the player's side. */
enum class Aim { Enemy, Blast, AllEnemies, Ally, AllAllies, Self }

sealed interface Effect {
    data class Damage(val mult: Double) : Effect                    // multiple of the user's ATK
    data class Heal(val mult: Double, val flat: Int) : Effect       // multiple of the user's ATK, plus a flat amount
    data class GainSp(val amount: Int) : Effect
    data class AtkMod(val pct: Int, val turns: Int) : Effect        // +buff or -debuff to ATK for N of the target's turns
    data class Shield(val mult: Double, val flat: Int) : Effect     // soaks damage until it runs out
}

data class Move(
    val id: String,
    val name: String,
    val kind: Kind,
    val aim: Aim,
    val spCost: Int,     // skills
    val spGain: Int,     // basics
    val energy: Int,     // energy the user gains
    val splash: Double,  // blast only: share of damage dealt to the neighbours of the target
    val effects: List<Effect>,
)

data class UnitDef(
    val id: String,
    val name: String,
    val side: Side,
    val avatar: String,
    val path: Path?,
    val hp: Int,
    val atk: Int,
    val def: Int,
    val spd: Int,
    val energyMax: Int,
    val moves: Map<String, Move>,
    val basic: String?,
    val skill: String?,
    val ultimate: String?,
    val pattern: List<String>,   // enemies: the moves they cycle through
)

data class BattleDef(
    val id: String,
    val title: String,
    val allies: List<String>,
    val enemies: List<String>,
    val startSp: Int,
    val maxSp: Int,
)

/** A gacha banner. [pool] is every 5-star hero that can drop; [featured] has a 50% share and a guarantee. */
data class Banner(val id: String, val name: String, val featured: String?, val pool: List<String>)

data class BattleData(val units: Map<String, UnitDef>, val battles: Map<String, BattleDef>, val banners: List<Banner> = emptyList())

enum class Outcome { Won, Lost }

class Mod(var pct: Int, var turns: Int)

class Fighter(val uid: String, val def: UnitDef) {
    val side: Side get() = def.side
    var hp: Int = def.hp
    var energy: Int = 0
    var shield: Int = 0
    var av: Double = 10000.0 / def.spd      // "action value": distance to travel before this fighter's turn
    val mods = mutableListOf<Mod>()
    var patternPos = 0

    val alive: Boolean get() = hp > 0
    val ultReady: Boolean get() = side == Side.Ally && def.energyMax > 0 && def.ultimate != null && energy >= def.energyMax
    val atk: Int get() = max(1, (def.atk * max(0.2, 1.0 + mods.sumOf { it.pct } / 100.0)).roundToInt())
}

/** What happened, in order, so a screen can animate it. Fighters are named by uid ("a0".."a3", "e0".."e4"). */
sealed interface BEvent {
    data class Used(val actor: String, val move: String) : BEvent
    data class Hit(val target: String, val amount: Int, val matchup: Int = 0) : BEvent   // matchup: +1 strong, -1 weak
    data class Shielded(val target: String, val amount: Int) : BEvent
    data class Healed(val target: String, val amount: Int) : BEvent
    data class Down(val target: String) : BEvent
    data class Modded(val target: String, val pct: Int, val turns: Int) : BEvent
    data class SpNow(val sp: Int) : BEvent
    data class Over(val outcome: Outcome) : BEvent
}
