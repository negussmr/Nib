package com.nibgame.app.gacha

import com.nibgame.app.battle.Banner
import com.nibgame.app.battle.UnitDef
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.random.Random

/** Sketch Fragments are the gear: four slots, one main stat each. */
enum class Slot { Head, Torso, Hands, Feet }
enum class Stat { HP, ATK, DEF, SPD }

data class Fragment(val id: Long, val name: String, val slot: Slot, val stat: Stat, val pct: Int)

/** One thing that came out of a pull. 5 stars = a hero, 4 = a Sketch Fragment, 3 = scraps that refund a little ink. */
sealed interface Drop {
    val stars: Int

    data class Hero(val id: String, val isNew: Boolean, val copies: Int) : Drop { override val stars: Int get() = 5 }
    data class Frag(val fragment: Fragment) : Drop { override val stars: Int get() = 4 }
    data class Scrap(val ink: Int) : Drop { override val stars: Int get() = 3 }
}

/** Everything the player owns. Saved with the game. */
data class Profile(
    val ink: Int = 3200,
    val owned: Map<String, Int> = mapOf("nib" to 0, "pica" to 0, "hatch" to 0),   // hero id -> extra copies
    val party: List<String> = listOf("nib", "pica", "hatch"),
    val fragments: List<Fragment> = emptyList(),
    val pity5: Int = 0,                 // pulls since the last 5-star
    val pity4: Int = 0,                 // pulls since the last 4-star or better
    val guaranteed: Boolean = false,    // the next 5-star is the featured one
    val pulls: Int = 0,
    val wonBattles: Set<String> = emptySet(),
    val nextFragmentId: Long = 1,
)

object Rewards {
    const val BATTLE_WIN = 100      // ink, first win of each battle
    const val CHAPTER_DONE = 300    // ink, first time a chapter is finished
}

object Gacha {
    const val COST = 160
    const val BASE_5 = 0.06
    const val SOFT_PITY = 20        // from this pull on, the 5-star chance climbs
    const val HARD_PITY = 30        // a 5-star is certain by this pull
    const val BASE_4 = 0.24
    const val FOUR_STAR_EVERY = 10  // at least one 4-star in every 10 pulls
    const val SCRAP_INK = 20
    const val MAX_COPIES = 6        // extra copies of a hero that still add power
    const val MAXED_REFUND = 100

    /** Chance that the next pull is a 5-star, given how many pulls have passed since the last one. */
    fun rate5(pity5: Int): Double {
        val n = pity5 + 1
        return when {
            n >= HARD_PITY -> 1.0
            n >= SOFT_PITY -> min(1.0, BASE_5 + (n - SOFT_PITY + 1) * 0.10)
            else -> BASE_5
        }
    }

    fun pull(p: Profile, banner: Banner, rng: Random): Pair<Profile, Drop> {
        require(p.ink >= COST) { "Not enough ink" }
        var s = p.copy(ink = p.ink - COST, pulls = p.pulls + 1)

        if (rng.nextDouble() < rate5(s.pity5)) {
            val featured = banner.featured
            val takeFeatured = featured != null && (s.guaranteed || rng.nextDouble() < 0.5)
            val id = if (takeFeatured) featured!! else {
                val others = banner.pool.filter { it != featured }.ifEmpty { banner.pool }
                others[rng.nextInt(others.size)]
            }
            val before = s.owned[id]
            val maxed = before != null && before >= MAX_COPIES
            val copies = if (before == null) 0 else min(before + 1, MAX_COPIES)
            s = s.copy(
                owned = s.owned + (id to copies),
                ink = s.ink + if (maxed) MAXED_REFUND else 0,
                pity5 = 0, pity4 = 0,
                guaranteed = featured != null && id != featured,
            )
            return s to Drop.Hero(id, isNew = before == null, copies = copies)
        }
        if (s.pity4 >= FOUR_STAR_EVERY - 1 || rng.nextDouble() < BASE_4) {
            val slot = Slot.entries[rng.nextInt(Slot.entries.size)]
            val stat = STATS.getValue(slot).let { it[rng.nextInt(it.size)] }
            val name = NAMES.getValue(slot).let { it[rng.nextInt(it.size)] }
            val f = Fragment(s.nextFragmentId, name, slot, stat, 4 + rng.nextInt(5))
            s = s.copy(fragments = s.fragments + f, nextFragmentId = s.nextFragmentId + 1, pity5 = s.pity5 + 1, pity4 = 0)
            return s to Drop.Frag(f)
        }
        s = s.copy(ink = s.ink + SCRAP_INK, pity5 = s.pity5 + 1, pity4 = s.pity4 + 1)
        return s to Drop.Scrap(SCRAP_INK)
    }

    fun pullMany(p: Profile, banner: Banner, count: Int, rng: Random): Pair<Profile, List<Drop>> {
        require(p.ink >= COST * count) { "Not enough ink" }
        var cur = p
        val out = ArrayList<Drop>()
        repeat(count) { val (np, d) = pull(cur, banner, rng); cur = np; out += d }
        return cur to out
    }

    private val STATS = mapOf(
        Slot.Head to listOf(Stat.HP), Slot.Torso to listOf(Stat.ATK),
        Slot.Hands to listOf(Stat.ATK, Stat.SPD), Slot.Feet to listOf(Stat.DEF, Stat.SPD),
    )

    // Fragments are pieces of things the white erased. Several names are printing terms on purpose.
    private val NAMES = mapOf(
        Slot.Head to listOf("Lamppost Glow", "Faded Halo", "Torn Hat Brim", "Halftone Crown"),
        Slot.Torso to listOf("Chalk Vest", "Scorched Sleeve", "Stitched Page", "Margin Coat"),
        Slot.Hands to listOf("Ink-Stained Glove", "Cracked Pencil", "Brass Nib", "Tracing Paper Cuff"),
        Slot.Feet to listOf("Worn Sole", "Scuffed Boot", "Footnote", "Registration Mark"),
    )
}

// ---- progression helpers ----------------------------------------------------------------------

fun Profile.winBattle(id: String): Profile =
    if (id in wonBattles) this else copy(ink = ink + Rewards.BATTLE_WIN, wonBattles = wonBattles + id)

fun Profile.toggleParty(id: String): Profile {
    if (id !in owned) return this
    return when {
        id in party -> if (party.size > 1) copy(party = party - id) else this
        party.size < 4 -> copy(party = party + id)
        else -> this
    }
}

/** Each extra copy of a hero adds 6% HP and ATK (up to 6 copies). */
fun UnitDef.withCopies(copies: Int): UnitDef {
    val k = 1.0 + 0.06 * min(copies, Gacha.MAX_COPIES)
    return copy(hp = (hp * k).roundToInt(), atk = (atk * k).roundToInt())
}
