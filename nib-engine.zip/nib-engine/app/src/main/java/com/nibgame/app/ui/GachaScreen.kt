package com.nibgame.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nibgame.app.UiState
import com.nibgame.app.gacha.Drop
import com.nibgame.app.gacha.Gacha
import kotlinx.coroutines.delay

/** The call-up board. Spend ink, pull a name out of the margin. */
@Composable
fun GachaScreen(ui: UiState, onPull: (Int) -> Unit, onCloseDrops: () -> Unit) {
    val drops = ui.drops
    if (drops != null) {
        DropsView(drops, ui, onCloseDrops)
        return
    }
    val p = ui.profile
    val banner = ui.banner
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(start = TextStart, end = 14.dp, top = 4.dp, bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (banner == null) {
            Text("No call-up is open right now.", style = hand(18))
            return@Column
        }
        val featured = banner.featured?.let { ui.units[it] }
        Column(Modifier.fillMaxWidth().sketchBox(banner.id.hashCode(), Ink.highlighter, Ink.red, width = 2.4.dp).padding(16.dp)) {
            Text(banner.name, style = hand(32))
            Spacer(Modifier.padding(top = 6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(ui.cast.speakers[banner.featured], 76.dp)
                Spacer(Modifier.width(14.dp))
                Column {
                    Text(featured?.name ?: "", style = hand(26))
                    PathBadge(featured?.path, 22.dp)
                    Text("Featured. Half of the agents you pull are them.", style = hand(14))
                }
            }
        }
        Text("Ink: ${p.ink}", style = hand(22))
        val left = Gacha.HARD_PITY - p.pity5
        Text(
            "Pulls since your last agent: ${p.pity5}. An agent is guaranteed within $left." +
                if (p.guaranteed) " Your next agent is the featured one." else "",
            style = hand(15, Ink.graphite),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PullButton("Pull once", Gacha.COST, p.ink >= Gacha.COST, Modifier.weight(1f)) { onPull(1) }
            PullButton("Pull ten", Gacha.COST * 10, p.ink >= Gacha.COST * 10, Modifier.weight(1f)) { onPull(10) }
        }
        Text(
            "About 6 in 100 pulls is an agent, rising after 20 and certain by 30. At least one sketch fragment in every 10. " +
                "Lose the 50/50 and the next agent is the featured one. A repeat agent gets 6% stronger, up to six times.",
            style = hand(13, Ink.graphite),
        )
    }
}

@Composable
private fun PullButton(label: String, cost: Int, enabled: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.alpha(if (enabled) 1f else .45f).sketchBox(label.hashCode(), Ink.bubble, Ink.blue, width = 2.2.dp)
            .clickable(enabled = enabled, onClick = onClick).padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(label, style = hand(20))
        Text("$cost ink", style = hand(14, Ink.graphite))
    }
}

@Composable
private fun DropsView(drops: List<Drop>, ui: UiState, onDone: () -> Unit) {
    var shown by remember(drops) { mutableStateOf(0) }
    val list = rememberLazyListState()
    LaunchedEffect(drops) {
        shown = 0
        while (shown < drops.size) {
            delay(280)
            shown++
        }
    }
    LaunchedEffect(shown) { if (shown > 0) list.animateScrollToItem(shown - 1) }
    Column(Modifier.fillMaxSize().padding(start = TextStart, end = 14.dp)) {
        LazyColumn(
            Modifier.weight(1f), state = list,
            contentPadding = PaddingValues(top = 6.dp, bottom = 10.dp), verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            itemsIndexed(drops.take(shown)) { _, d -> DropCard(d, ui) }
        }
        if (shown >= drops.size) {
            Box(Modifier.fillMaxWidth().padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
                Box(
                    Modifier.sketchBox(7, Ink.highlighter, Ink.blue, width = 2.dp).clickable(onClick = onDone)
                        .padding(horizontal = 30.dp, vertical = 12.dp),
                ) { Text("Done", style = hand(20)) }
            }
        }
    }
}

@Composable
private fun DropCard(d: Drop, ui: UiState) {
    when (d) {
        is Drop.Hero -> {
            val u = ui.units[d.id]
            Row(
                Modifier.fillMaxWidth().sketchBox(d.id.hashCode(), Ink.highlighter, Ink.red, width = 2.4.dp).padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Avatar(ui.cast.speakers[d.id], 56.dp)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(u?.name ?: d.id, style = hand(26))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        PathBadge(u?.path, 20.dp)
                        Text(
                            if (d.isNew) "  New agent!" else "  Repeat, now +${d.copies}",
                            style = hand(16, Ink.red),
                        )
                    }
                    Text("5 stars", style = hand(13, Ink.graphite))
                }
            }
        }
        is Drop.Frag -> {
            val f = d.fragment
            Column(Modifier.fillMaxWidth().sketchBox(f.id.toInt(), Ink.bubble, Ink.blue, width = 2.dp).padding(horizontal = 14.dp, vertical = 10.dp)) {
                Text(f.name, style = hand(21))
                Text("${f.slot.name} fragment, +${f.pct}% ${f.stat.name}", style = hand(14, Ink.graphite))
                Text("4 stars", style = hand(13, Ink.graphite))
            }
        }
        is Drop.Scrap -> Text(
            "Scraps. +${d.ink} ink back.", style = hand(15, Ink.graphite).copy(textAlign = TextAlign.Start),
            modifier = Modifier.padding(start = 6.dp, top = 2.dp, bottom = 2.dp),
        )
    }
}
