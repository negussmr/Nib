package com.nibgame.app.engine

import com.nibgame.app.gacha.Fragment
import com.nibgame.app.gacha.Profile
import com.nibgame.app.gacha.Slot
import com.nibgame.app.gacha.Stat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class ChapterProgress(
    val pc: Int = 0,
    val done: Boolean = false,
    val history: List<ChatItem> = emptyList(),
)

data class SaveData(
    val vars: Map<String, Int> = emptyMap(),
    val chapters: Map<String, ChapterProgress> = emptyMap(),
    val lastCheckMs: Long = 0L,
    val profile: Profile = Profile(),
)

/** Saves to one small JSON file. Writes go to a temp file first so a crash can't leave half a save. */
class SaveStore(private val file: File) {

    fun load(): SaveData {
        if (!file.exists()) return SaveData()
        return try {
            decode(file.readText())
        } catch (e: Exception) {
            runCatching { file.copyTo(File(file.path + ".bad"), overwrite = true) }
            SaveData()
        }
    }

    fun write(data: SaveData) {
        val tmp = File(file.path + ".tmp")
        tmp.writeText(encode(data))
        if (!tmp.renameTo(file)) {
            file.delete()
            tmp.renameTo(file)
        }
    }

    fun encode(d: SaveData): String {
        val root = JSONObject()
        root.put("lastCheck", d.lastCheckMs)
        val vars = JSONObject()
        d.vars.forEach { (k, v) -> vars.put(k, v) }
        root.put("vars", vars)
        val chapters = JSONObject()
        d.chapters.forEach { (id, p) ->
            val c = JSONObject()
            c.put("pc", p.pc)
            c.put("done", p.done)
            val h = JSONArray()
            p.history.forEach { h.put(item(it)) }
            c.put("history", h)
            chapters.put(id, c)
        }
        root.put("chapters", chapters)
        root.put("profile", profileJson(d.profile))
        return root.toString()
    }

    fun decode(text: String): SaveData {
        val root = JSONObject(text)
        val vars = HashMap<String, Int>()
        root.optJSONObject("vars")?.let { v ->
            for (k in v.keys()) vars[k.toString()] = v.getInt(k.toString())
        }
        val chapters = HashMap<String, ChapterProgress>()
        root.optJSONObject("chapters")?.let { cs ->
            for (k in cs.keys()) {
                val id = k.toString()
                val c = cs.getJSONObject(id)
                val items = ArrayList<ChatItem>()
                val h = c.optJSONArray("history")
                if (h != null) for (i in 0 until h.length()) items.add(item(h.getJSONObject(i)))
                chapters[id] = ChapterProgress(c.optInt("pc", 0), c.optBoolean("done", false), items)
            }
        }
        val profile = root.optJSONObject("profile")?.let { profileFrom(it) } ?: Profile()
        return SaveData(vars, chapters, root.optLong("lastCheck", 0L), profile)
    }

    private fun profileJson(p: Profile): JSONObject {
        val o = JSONObject()
        o.put("ink", p.ink); o.put("pity5", p.pity5); o.put("pity4", p.pity4); o.put("guaranteed", p.guaranteed)
        o.put("pulls", p.pulls); o.put("nextFrag", p.nextFragmentId)
        val owned = JSONObject(); p.owned.forEach { (k, v) -> owned.put(k, v) }; o.put("owned", owned)
        o.put("party", JSONArray().also { a -> p.party.forEach { a.put(it) } })
        o.put("won", JSONArray().also { a -> p.wonBattles.forEach { a.put(it) } })
        o.put("fragments", JSONArray().also { a ->
            p.fragments.forEach { f ->
                a.put(JSONObject().put("id", f.id).put("name", f.name).put("slot", f.slot.name).put("stat", f.stat.name).put("pct", f.pct))
            }
        })
        return o
    }

    private fun profileFrom(o: JSONObject): Profile {
        val d = Profile()
        val owned = LinkedHashMap<String, Int>()
        o.optJSONObject("owned")?.let { j -> for (k in j.keys()) owned[k.toString()] = j.getInt(k.toString()) }
        val party = ArrayList<String>()
        o.optJSONArray("party")?.let { a -> for (i in 0 until a.length()) party.add(a.getString(i)) }
        val won = HashSet<String>()
        o.optJSONArray("won")?.let { a -> for (i in 0 until a.length()) won.add(a.getString(i)) }
        val frags = ArrayList<Fragment>()
        o.optJSONArray("fragments")?.let { a ->
            for (i in 0 until a.length()) {
                val f = a.getJSONObject(i)
                frags.add(Fragment(f.getLong("id"), f.getString("name"), Slot.valueOf(f.getString("slot")), Stat.valueOf(f.getString("stat")), f.getInt("pct")))
            }
        }
        return Profile(
            ink = o.optInt("ink", d.ink), owned = if (owned.isEmpty()) d.owned else owned,
            party = if (party.isEmpty()) d.party else party, fragments = frags,
            pity5 = o.optInt("pity5", 0), pity4 = o.optInt("pity4", 0), guaranteed = o.optBoolean("guaranteed", false),
            pulls = o.optInt("pulls", 0), wonBattles = won, nextFragmentId = o.optLong("nextFrag", 1),
        )
    }

    private fun item(i: ChatItem): JSONObject {
        val o = JSONObject()
        when (i) {
            is ChatItem.Bubble -> { o.put("t", "b"); o.put("id", i.id); o.put("who", i.who); o.put("text", i.text); o.put("mine", i.mine) }
            is ChatItem.Note -> { o.put("t", "n"); o.put("id", i.id); o.put("text", i.text) }
            is ChatItem.Card -> { o.put("t", "c"); o.put("id", i.id); o.put("title", i.title); o.put("note", i.note) }
        }
        return o
    }

    private fun item(o: JSONObject): ChatItem = when (o.getString("t")) {
        "b" -> ChatItem.Bubble(o.getLong("id"), o.getString("who"), o.getString("text"), o.getBoolean("mine"))
        "n" -> ChatItem.Note(o.getLong("id"), o.getString("text"))
        else -> ChatItem.Card(o.getLong("id"), o.getString("title"), o.getString("note"))
    }
}
