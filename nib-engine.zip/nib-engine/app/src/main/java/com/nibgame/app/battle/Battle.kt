package com.nibgame.app.battle

import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * One fight. Pure rules, no screens, so it can be tested without a phone.
 *
 * Loop for a screen:
 *   val who = battle.nextTurn()           // null when the fight is over
 *   if (who is an enemy) battle.enemyTurn()
 *   else show battle.options(), battle.ultimates(), battle.targets(move), then battle.act(move, target)
 * Every call returns the list of events to animate.
 *
 * Turn order works like Honkai: Star Rail. Everyone has a distance of 10000/SPD to travel; whoever
 * is closest to the finish line acts, then goes back to the start. Faster fighters act more often.
 */
class Battle(val def: BattleDef, units: Map<String, UnitDef>, seed: Int = 1) {
    private val rng = Random(seed)

    val allies: List<Fighter> = def.allies.mapIndexed { i, id -> Fighter("a$i", units.getValue(id)) }
    val enemies: List<Fighter> = def.enemies.mapIndexed { i, id -> Fighter("e$i", units.getValue(id)) }
    val everyone: List<Fighter> = allies + enemies

    var sp: Int = def.startSp
        private set
    var outcome: Outcome? = null
        private set
    var current: Fighter? = null
        private set

    fun fighter(uid: String): Fighter = everyone.first { it.uid == uid }
    fun livingAllies(): List<Fighter> = allies.filter { it.alive }
    fun livingEnemies(): List<Fighter> = enemies.filter { it.alive }

    /** Who acts next. The first entry is the fighter whose turn it is right now, if one is in progress. */
    fun upcoming(count: Int): List<Fighter> {
        val av = LinkedHashMap<Fighter, Double>()
        everyone.filter { it.alive }.forEach { av[it] = it.av }
        val out = ArrayList<Fighter>()
        repeat(count) {
            if (av.isEmpty()) return out
            val next = av.entries.minByOrNull { it.value }!!.key
            val step = av.getValue(next)
            for (k in av.keys.toList()) av[k] = av.getValue(k) - step
            av[next] = 10000.0 / next.def.spd
            out += next
        }
        return out
    }

    fun nextTurn(): Fighter? {
        if (outcome != null) return null
        val alive = everyone.filter { it.alive }
        val actor = alive.minByOrNull { it.av }!!     // ties go to allies, because they come first in the list
        val step = actor.av
        alive.forEach { it.av -= step }
        current = actor
        return actor
    }

    // ---- the player's side ----------------------------------------------------------------

    /** Basic and skill moves the current ally can use right now (a skill needs enough skill points). */
    fun options(): List<Move> {
        val f = current ?: return emptyList()
        if (f.side != Side.Ally || outcome != null) return emptyList()
        val d = f.def
        val out = ArrayList<Move>()
        d.basic?.let { out += d.moves.getValue(it) }
        d.skill?.let { id -> d.moves.getValue(id).let { if (sp >= it.spCost) out += it } }
        return out
    }

    /** Allies whose energy bar is full. An ultimate can be fired during any ally's turn and does not use up the turn. */
    fun ultimates(): List<Fighter> =
        if (current?.side == Side.Ally && outcome == null) livingAllies().filter { it.ultReady } else emptyList()

    /** Who a move can be aimed at. Empty means it picks its own targets. */
    fun targets(move: Move, actor: Fighter): List<Fighter> {
        val foes = if (actor.side == Side.Ally) livingEnemies() else livingAllies()
        val friends = if (actor.side == Side.Ally) livingAllies() else livingEnemies()
        return when (move.aim) {
            Aim.Enemy, Aim.Blast -> foes
            Aim.Ally -> friends
            else -> emptyList()
        }
    }

    fun act(move: Move, target: Fighter?): List<BEvent> {
        val actor = checkNotNull(current) { "Nobody is acting" }
        check(actor.side == Side.Ally) { "It is not an ally's turn" }
        check(options().any { it.id == move.id }) { "${move.name} is not available" }
        checkTarget(actor, move, target)
        val ev = ArrayList<BEvent>()
        execute(actor, move, target, ev)
        finishTurn(actor, ev)
        return ev
    }

    fun ultimate(caster: Fighter, target: Fighter?): List<BEvent> {
        check(caster in ultimates()) { "${caster.def.name} cannot use an ultimate right now" }
        val move = caster.def.moves.getValue(caster.def.ultimate!!)
        checkTarget(caster, move, target)
        val ev = ArrayList<BEvent>()
        execute(caster, move, target, ev)
        settle(ev)
        return ev
    }

    // ---- the enemy side -------------------------------------------------------------------

    fun enemyTurn(): List<BEvent> {
        val actor = checkNotNull(current) { "Nobody is acting" }
        check(actor.side == Side.Enemy) { "It is not an enemy's turn" }
        val d = actor.def
        val move = d.moves.getValue(d.pattern[actor.patternPos % d.pattern.size])
        actor.patternPos++
        val target = if (move.aim == Aim.Enemy || move.aim == Aim.Blast) livingAllies().random(rng) else null
        val ev = ArrayList<BEvent>()
        execute(actor, move, target, ev)
        finishTurn(actor, ev)
        return ev
    }

    // ---- rules ----------------------------------------------------------------------------

    private fun checkTarget(actor: Fighter, move: Move, target: Fighter?) {
        val valid = targets(move, actor)
        if (valid.isNotEmpty()) check(target != null && target in valid) { "${move.name} needs a valid target" }
    }

    private fun execute(actor: Fighter, move: Move, chosen: Fighter?, ev: MutableList<BEvent>) {
        ev += BEvent.Used(actor.uid, move.name)
        val foes = if (actor.side == Side.Ally) livingEnemies() else livingAllies()
        val friends = if (actor.side == Side.Ally) livingAllies() else livingEnemies()
        val main: List<Fighter> = when (move.aim) {
            Aim.Enemy, Aim.Blast -> listOf(chosen ?: foes.first())
            Aim.AllEnemies -> foes
            Aim.Ally -> listOf(chosen ?: friends.first())
            Aim.AllAllies -> friends
            Aim.Self -> listOf(actor)
        }
        for (e in move.effects) {
            when (e) {
                is Effect.Damage -> {
                    main.forEach { hit(actor, it, e.mult, ev) }
                    if (move.aim == Aim.Blast) {
                        val i = foes.indexOf(main[0])
                        listOfNotNull(foes.getOrNull(i - 1), foes.getOrNull(i + 1)).forEach { hit(actor, it, e.mult * move.splash, ev) }
                    }
                }
                is Effect.Heal -> main.forEach { t ->
                    if (t.alive) {
                        val amount = min(t.def.hp - t.hp, (actor.atk * e.mult).roundToInt() + e.flat)
                        if (amount > 0) { t.hp += amount; ev += BEvent.Healed(t.uid, amount) }
                    }
                }
                is Effect.Shield -> main.forEach { t ->
                    if (t.alive) {
                        val amount = (actor.atk * e.mult).roundToInt() + e.flat
                        t.shield += amount
                        ev += BEvent.Shielded(t.uid, amount)
                    }
                }
                is Effect.GainSp -> sp = min(def.maxSp, sp + e.amount)
                is Effect.AtkMod -> main.forEach { if (it.alive) { it.mods += Mod(e.pct, e.turns); ev += BEvent.Modded(it.uid, e.pct, e.turns) } }
            }
        }
        if (actor.side == Side.Ally) {
            when (move.kind) {
                Kind.Basic -> sp = min(def.maxSp, sp + move.spGain)
                Kind.Skill -> sp = max(0, sp - move.spCost)
                Kind.Ultimate -> actor.energy = 0
                Kind.Enemy -> Unit
            }
            actor.energy = min(actor.def.energyMax, actor.energy + move.energy)
            ev += BEvent.SpNow(sp)
        }
    }

    /** Damage = ATK x multiplier, softened by the target's DEF. No randomness, so fights are reproducible. */
    private fun hit(actor: Fighter, target: Fighter, mult: Double, ev: MutableList<BEvent>) {
        if (!target.alive) return
        val matchup = Matchups.versus(actor.def.path, target.def.path)
        val dmg = max(1, (actor.atk * mult * Matchups.multiplier(matchup) * 100.0 / (100.0 + target.def.def)).roundToInt())
        val soaked = min(target.shield, dmg)
        target.shield -= soaked
        target.hp = max(0, target.hp - (dmg - soaked))
        ev += BEvent.Hit(target.uid, dmg, matchup)
        if (target.side == Side.Ally && target.def.energyMax > 0) target.energy = min(target.def.energyMax, target.energy + 10)
        if (!target.alive) ev += BEvent.Down(target.uid)
    }

    private fun settle(ev: MutableList<BEvent>) {
        if (outcome != null) return
        outcome = when {
            livingEnemies().isEmpty() -> Outcome.Won
            livingAllies().isEmpty() -> Outcome.Lost
            else -> null
        }
        outcome?.let { ev += BEvent.Over(it) }
    }

    private fun finishTurn(actor: Fighter, ev: MutableList<BEvent>) {
        settle(ev)
        if (outcome != null) return
        actor.mods.forEach { it.turns-- }
        actor.mods.removeAll { it.turns <= 0 }
        actor.av = 10000.0 / actor.def.spd
        current = null
    }
}
