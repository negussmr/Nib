package com.nibgame.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.dp
import com.nibgame.app.ChapterEntry
import com.nibgame.app.Config
import com.nibgame.app.Status
import com.nibgame.app.Tab
import com.nibgame.app.UiState

@Composable
fun HomeScreen(
    ui: UiState,
    onOpen: (String) -> Unit,
    onCheck: () -> Unit,
    onTab: (Tab) -> Unit,
    onToggle: (String) -> Unit,
    onPull: (Int) -> Unit,
    onCloseDrops: () -> Unit,
) {
    Column(Modifier.fillMaxSize().notebook().statusBarsPadding().navigationBarsPadding()) {
        Box(Modifier.fillMaxWidth()) {
            Avatar(ui.cast.speakers[ui.cast.player], 40.dp, Modifier.padding(start = 7.dp, top = 30.dp))
            Column(Modifier.padding(start = TextStart, end = 16.dp, top = 20.dp, bottom = 8.dp)) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(Config.GAME_TITLE, style = hand(44), modifier = Modifier.weight(1f))
                    Text("Ink ${ui.profile.ink}", style = hand(18, Ink.graphite), modifier = Modifier.padding(bottom = 6.dp))
                }
                ui.notice?.let { Text(it, style = hand(16, Ink.red), modifier = Modifier.padding(top = 2.dp)) }
            }
        }
        Box(Modifier.weight(1f)) {
            when (ui.tab) {
                Tab.Story -> StoryList(ui, onOpen, onCheck)
                Tab.Team -> TeamScreen(ui, onToggle)
                Tab.Pull -> GachaScreen(ui, onPull, onCloseDrops)
            }
        }
        TabBar(ui.tab, onTab)
    }
}

@Composable
private fun TabBar(current: Tab, onTab: (Tab) -> Unit) {
    Row(
        Modifier.fillMaxWidth().drawBehind {
            drawLine(Ink.graphite, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = 1.dp.toPx())
        }.padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        listOf(Tab.Story to "Story", Tab.Team to "Team", Tab.Pull to "Call-up").forEach { (tab, label) ->
            val selected = tab == current
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                Box(
                    (if (selected) Modifier.sketchBox(label.hashCode(), Ink.highlighter, Ink.blue, radius = 10.dp, width = 1.6.dp) else Modifier)
                        .clickable { onTab(tab) }.padding(horizontal = 18.dp, vertical = 9.dp),
                ) { Text(label, style = hand(18, if (selected) Ink.blue else Ink.graphite)) }
            }
        }
    }
}

@Composable
private fun StoryList(ui: UiState, onOpen: (String) -> Unit, onCheck: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(start = TextStart, end = 16.dp, top = 4.dp, bottom = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            itemsIndexed(ui.entries, key = { _, e -> e.info.id }) { index, entry ->
                ChapterCard(index + 1, entry, onOpen)
            }
        }
        Text(
            "Check for new chapters",
            style = hand(16, Ink.graphite),
            modifier = Modifier.clickable(onClick = onCheck).padding(start = TextStart, end = 16.dp, top = 8.dp, bottom = 10.dp),
        )
    }
}

@Composable
private fun ChapterCard(number: Int, entry: ChapterEntry, onOpen: (String) -> Unit) {
    val locked = entry.status == Status.Locked
    val note = when (entry.status) {
        Status.Locked -> "Finish the chapter before this one"
        Status.New -> "New"
        Status.InProgress -> "Keep reading"
        Status.Done -> "Read. Tap to look back"
    }
    Column(
        Modifier.fillMaxWidth().alpha(if (locked) 0.5f else 1f)
            .sketchBox(entry.info.id.hashCode(), Ink.bubble, Ink.blue, width = 2.dp)
            .clickable(enabled = !locked) { onOpen(entry.info.id) }
            .padding(horizontal = 18.dp, vertical = 14.dp),
    ) {
        Text("Chapter $number", style = hand(14, Ink.graphite))
        Text(entry.info.title, style = hand(24))
        Text(note, style = hand(15, if (entry.status == Status.New) Ink.red else Ink.graphite))
    }
}
