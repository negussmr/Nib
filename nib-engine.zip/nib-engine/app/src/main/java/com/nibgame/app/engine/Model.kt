package com.nibgame.app.engine

/** Highest content format this build of the app understands. Bump it when you add new step types. */
const val SCHEMA_SUPPORTED = 2

class StoryFormatException(message: String) : Exception(message)

data class Speaker(
    val id: String,
    val name: String,
    val avatar: String, // which stickman to draw: nib, pica, hatch, mystery; anything else = plain
    val ink: Long,      // pen colour, 0xAARRGGBB
    val accent: Long,
)

data class Cast(val player: String, val speakers: Map<String, Speaker>)

/** One reply the player can pick. */
data class Opt(
    val text: String,
    val goto: String?,
    val set: List<String>,
    val cond: String?,
    val once: Boolean,
)

sealed interface Step {
    data class Say(val who: String, val text: String, val typingMs: Long?) : Step
    data class Narr(val text: String) : Step
    data class Choice(val options: List<Opt>) : Step
    data class Label(val name: String) : Step
    data class Goto(val label: String) : Step
    data class SetVars(val ops: List<String>) : Step
    data class If(val cond: String, val label: String) : Step
    data class Wait(val ms: Long) : Step
    data class Give(val itemId: String, val name: String, val note: String) : Step
    /** Start a fight from gamedata.json. [win] is where to jump after winning; null means carry on. */
    data class Battle(val id: String, val win: String?) : Step
    data object End : Step
}

class Chapter(val id: String, val title: String, val steps: List<Step>) {
    private val labels: Map<String, Int> = buildMap {
        steps.forEachIndexed { i, s -> if (s is Step.Label) put(s.name, i) }
    }

    fun hasLabel(name: String) = name in labels

    fun labelIndex(name: String): Int =
        labels[name] ?: throw StoryFormatException("Chapter '$id' has no label '$name'")
}

data class ChapterInfo(val id: String, val file: String, val title: String, val rev: Int)

data class Manifest(val version: Int, val schema: Int, val cast: String, val data: String, val chapters: List<ChapterInfo>)

/** What the engine asks the screen to show next. */
sealed interface Event {
    data class Message(val who: String, val text: String, val typingMs: Long?) : Event
    data class Note(val text: String) : Event
    data class Pause(val ms: Long) : Event
    data class Reward(val itemId: String, val name: String, val note: String) : Event
    data class Choices(val texts: List<String>) : Event
    data class Battle(val id: String) : Event
    data object End : Event
}

/** One line of the chat, as displayed and as saved. */
sealed interface ChatItem {
    val id: Long

    data class Bubble(override val id: Long, val who: String, val text: String, val mine: Boolean) : ChatItem
    data class Note(override val id: Long, val text: String) : ChatItem
    data class Card(override val id: Long, val title: String, val note: String) : ChatItem
}
