package com.nibgame.app.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nibgame.app.battle.Path as BPath
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * Heads, bodies and monsters, drawn with the same wobbly pen as the avatars.
 * Head features are measured in units of the head radius, so one drawing serves both
 * the small round portrait and the full-body figure.
 */
fun DrawScope.drawHead(kind: String, c: Offset, r: Float, ink: Color, accent: Color, seed: Int) {
    fun pts(vararg v: Float): List<Offset> = (0 until v.size / 2).map { Offset(c.x + v[2 * it] * r, c.y + v[2 * it + 1] * r) }
    fun u(x: Float, y: Float) = Offset(c.x + x * r, c.y + y * r)
    val w = r * .25f
    val wob = r * .06f
    fun stroke(p: List<Offset>, col: Color, width: Float, s: Int, sharp: Boolean = false, closed: Boolean = false, passes: Int = 1) =
        inkStroke(p, col, width, seed + s, closed = closed, wobble = wob, passes = passes, sharp = sharp)
    fun dot(x: Float, y: Float, rad: Float = .11f) = drawCircle(ink, radius = rad * r, center = u(x, y))
    fun smile() = stroke(pts(-.25f, .45f, 0f, .525f, .25f, .45f), ink, w * .7f, 3)

    val head = circlePts(c, r, 12)
    when (kind) {
        "nib" -> {
            stroke(head, ink, w, 1, closed = true, passes = 2)
            dot(-.35f, 0f); dot(.35f, 0f); smile()
            stroke(pts(-1f, 1.35f, 0f, 1.6f, 1f, 1.35f), accent, w * 2.0f, 4)
            stroke(pts(.6f, 1.55f, .85f, 2.05f, .65f, 2.5f), accent, w * 1.7f, 5)
            stroke(pts(-.1f, -.95f, .1f, -1.45f, .55f, -1.4f, .4f, -1.05f), ink, w, 6, passes = 2)
        }
        "pica" -> {
            stroke(head, ink, w, 1, closed = true, passes = 2)
            stroke(circlePts(u(0f, -1.25f), .325f * r, 8), ink, w, 2, closed = true, passes = 2)
            stroke(circlePts(u(-.45f, 0f), .26f * r, 8), accent, w * .9f, 3, closed = true)
            stroke(circlePts(u(.45f, 0f), .26f * r, 8), accent, w * .9f, 4, closed = true)
            stroke(pts(-.19f, 0f, .19f, 0f), accent, w * .8f, 5)
            dot(-.45f, 0f); dot(.45f, 0f); smile()
        }
        "hatch" -> {
            stroke(pts(-.95f, -.8f, .95f, -.8f, 1.15f, .2f, 0f, 1.25f, -1.15f, .2f), ink, w, 1, sharp = true, closed = true, passes = 2)
            stroke(pts(-.95f, -.8f, -.65f, -1.5f, -.25f, -.95f, .15f, -1.6f, .55f, -.95f, .95f, -.8f), ink, w, 2, sharp = true, passes = 2)
            stroke(pts(-.6f, .05f, -.2f, .15f), ink, w * .9f, 3, sharp = true)
            stroke(pts(.2f, .15f, .6f, .05f), ink, w * .9f, 4, sharp = true)
            stroke(pts(.4f, -.55f, .65f, .15f), accent, w * .8f, 5, sharp = true)
        }
        "mystery" -> {
            stroke(head, Ink.graphite, w, 1, closed = true, passes = 2)
            stroke((0..9).flatMap { i -> listOf(-.9f + .2f * i, if (i % 2 == 0) -.55f else .55f) }.let { pts(*it.toFloatArray()) }, accent, w * .9f, 2, sharp = true)
            stroke(pts(-.8f, -.65f, .8f, .65f), accent, w * 1.3f, 3, sharp = true, passes = 2)
            stroke(pts(.8f, -.65f, -.8f, .65f), accent, w * 1.3f, 4, sharp = true, passes = 2)
        }
        "bleed" -> {      // Cyan: long hair that drips like wet ink
            stroke(head, ink, w, 1, closed = true, passes = 2)
            stroke(pts(-.9f, -.7f, 0f, -1.05f, .9f, -.7f), accent, w * 1.2f, 2)
            stroke(pts(-1f, -.3f, -1.15f, .4f, -1.25f, 1.3f), accent, w * 1.1f, 3)
            stroke(pts(1f, -.3f, 1.15f, .4f, 1.25f, 1.3f), accent, w * 1.1f, 4)
            stroke(pts(-.55f, 0f, -.35f, .14f, -.15f, 0f), ink, w * .8f, 5)
            stroke(pts(.15f, 0f, .35f, .14f, .55f, 0f), ink, w * .8f, 6)
            smile()
        }
        "crumb" -> {      // Eraser: wears a little pink eraser as a hat
            val hat = pts(-.8f, -1.0f, .8f, -1.0f, .8f, -1.75f, -.8f, -1.75f)
            drawPath(sharpPath(hat, true), color = accent, alpha = .7f)
            stroke(hat, ink, w, 2, sharp = true, closed = true, passes = 2)
            stroke(pts(-.8f, -1.38f, .8f, -1.38f), ink, w * .7f, 3, sharp = true)
            stroke(head, ink, w, 1, closed = true, passes = 2)
            dot(-.35f, 0f); dot(.35f, 0f); smile()
        }
        "scuff" -> {      // Friction: headband, scuffed cheek
            stroke(head, ink, w, 1, closed = true, passes = 2)
            stroke(pts(-1f, -.5f, 0f, -.4f, 1f, -.5f), accent, w * 1.6f, 2)
            stroke(pts(1f, -.5f, 1.45f, -.2f), accent, w, 3)
            stroke(pts(1f, -.5f, 1.4f, -.8f), accent, w, 4)
            stroke(pts(-.9f, .35f, -.55f, .6f), ink, w * .8f, 5, sharp = true)
            stroke(pts(-.8f, .12f, -.5f, .37f), ink, w * .8f, 6, sharp = true)
            dot(-.35f, 0f); dot(.35f, 0f)
            stroke(pts(-.25f, .5f, .25f, .5f), ink, w * .7f, 7)
        }
        "scrawl" -> {     // Scribble: wild hair, wide eyes, jagged grin
            stroke(circlePts(u(-.55f, -1.1f), .5f * r, 7), accent, w * .8f, 2, closed = true)
            stroke(circlePts(u(0f, -1.35f), .55f * r, 7), accent, w * .8f, 3, closed = true)
            stroke(circlePts(u(.55f, -1.1f), .5f * r, 7), accent, w * .8f, 4, closed = true)
            stroke(head, ink, w, 1, closed = true, passes = 2)
            stroke(circlePts(u(-.4f, 0f), .24f * r, 8), ink, w * .7f, 5, closed = true)
            stroke(circlePts(u(.4f, 0f), .24f * r, 8), ink, w * .7f, 6, closed = true)
            dot(-.4f, 0f, .07f); dot(.4f, 0f, .07f)
            stroke(pts(-.5f, .5f, -.25f, .75f, 0f, .5f, .25f, .75f, .5f, .5f), ink, w * .7f, 7, sharp = true)
        }
        else -> {
            stroke(head, ink, w, 1, closed = true, passes = 2)
            dot(-.35f, 0f); dot(.35f, 0f); smile()
        }
    }
}

/** A full-body stickman standing at [x] with its feet on [foot], [h] tall. */
fun DrawScope.drawFigure(kind: String, ink: Color, accent: Color, seed: Int, x: Float, foot: Float, h: Float) {
    fun p(u: Float, v: Float) = Offset(x + u * h, foot - v * h)
    val w = h * .032f
    val wob = h * .007f
    inkStroke(listOf(p(0f, .68f), p(0f, .38f)), ink, w, seed + 11, wobble = wob)
    inkStroke(listOf(p(0f, .60f), p(-.17f, .46f)), ink, w, seed + 12, wobble = wob)
    inkStroke(listOf(p(0f, .60f), p(.17f, .46f)), ink, w, seed + 13, wobble = wob)
    inkStroke(listOf(p(0f, .38f), p(-.12f, 0f)), ink, w, seed + 14, wobble = wob)
    inkStroke(listOf(p(0f, .38f), p(.12f, 0f)), ink, w, seed + 15, wobble = wob)
    drawHead(kind, p(0f, .80f), h * .12f, ink, accent, seed)
    if (kind == "hatch") {
        inkStroke(listOf(p(.17f, .46f), p(.33f, .78f)), ink, w * 1.4f, seed + 16, wobble = wob, sharp = true)
        inkStroke(listOf(p(.27f, .58f), p(.38f, .50f)), ink, w, seed + 17, passes = 1, wobble = wob * .4f, sharp = true)
    }
}

/** The things the white sends. Blanks are patches where the page has been erased. */
fun DrawScope.drawEnemy(kind: String, cx: Float, cy: Float, s: Float, seed: Int) {
    val c = Offset(cx, cy)
    val rnd = Random(seed)
    fun blob(rx: Float, ry: Float, n: Int, wob: Float): List<Offset> = (0 until n).map {
        val a = 2.0 * PI * it / n
        val k = 1f + (rnd.nextFloat() - .5f) * 2f * wob
        Offset(c.x + rx * k * cos(a).toFloat(), c.y + ry * k * sin(a).toFloat())
    }
    when (kind) {
        "blank" -> {
            val rim = blob(s * .5f, s * .46f, 28, .05f)
            drawPath(smoothPath(rim, true), color = Color(0xFFFBFCFD))
            rim.forEach { drawCircle(Ink.graphite, radius = s * .018f, center = it) }
            drawCircle(Ink.graphite, radius = s * .045f, center = Offset(c.x - s * .16f, c.y - s * .06f))
            drawCircle(Ink.graphite, radius = s * .045f, center = Offset(c.x + s * .16f, c.y - s * .06f))
        }
        "smudge" -> {
            val b = blob(s * .46f, s * .4f, 9, .18f)
            drawPath(smoothPath(b, true), color = Ink.graphite, alpha = .22f)
            repeat(22) {
                val a = rnd.nextFloat() * 6.28f
                val d = rnd.nextFloat() * .4f * s
                val x = c.x + cos(a) * d
                val y = c.y + sin(a) * d * .85f
                inkStroke(listOf(Offset(x - .14f * s, y - .05f * s), Offset(x + .14f * s, y + .07f * s)), Ink.graphite, s * .016f, seed + it, passes = 1, wobble = s * .005f, sharp = true)
            }
            inkStroke(b, Ink.graphite, s * .025f, seed + 1, closed = true, wobble = s * .01f)
            drawCircle(Color.White, radius = s * .05f, center = Offset(c.x - s * .15f, c.y - s * .05f))
            drawCircle(Color.White, radius = s * .05f, center = Offset(c.x + s * .15f, c.y - s * .05f))
        }
        "scribbler" -> {
            inkStroke(circlePts(Offset(c.x - s * .16f, c.y), s * .27f, 8), Ink.graphite, s * .02f, seed + 1, closed = true, wobble = s * .02f)
            inkStroke(circlePts(Offset(c.x + s * .16f, c.y - s * .04f), s * .27f, 8), Ink.graphite, s * .02f, seed + 2, closed = true, wobble = s * .02f)
            inkStroke(circlePts(Offset(c.x, c.y + s * .08f), s * .3f, 9), Ink.red, s * .02f, seed + 3, closed = true, wobble = s * .02f)
            drawCircle(Color.White, radius = s * .06f, center = Offset(c.x - s * .12f, c.y))
            drawCircle(Color.White, radius = s * .06f, center = Offset(c.x + s * .12f, c.y))
            drawCircle(Ink.graphite, radius = s * .025f, center = Offset(c.x - s * .12f, c.y))
            drawCircle(Ink.graphite, radius = s * .025f, center = Offset(c.x + s * .12f, c.y))
        }
        "eraser" -> {     // a pink rubber with a cardboard sleeve, and a face
            val w = s * .5f
            val h = s * .36f
            val body = listOf(
                Offset(c.x - w * .85f, c.y - h), Offset(c.x + w * .85f, c.y - h), Offset(c.x + w, c.y - h * .8f), Offset(c.x + w, c.y + h * .8f),
                Offset(c.x + w * .85f, c.y + h), Offset(c.x - w * .85f, c.y + h), Offset(c.x - w, c.y + h * .8f), Offset(c.x - w, c.y - h * .8f),
            )
            drawPath(sharpPath(body, true), color = Color(0xFFF2A7A4))
            val sleeve = listOf(
                Offset(c.x + w * .2f, c.y - h), Offset(c.x + w * .85f, c.y - h), Offset(c.x + w, c.y - h * .8f), Offset(c.x + w, c.y + h * .8f),
                Offset(c.x + w * .85f, c.y + h), Offset(c.x + w * .2f, c.y + h),
            )
            drawPath(sharpPath(sleeve, true), color = Color(0xFF5B6B8C), alpha = .85f)
            inkStroke(body, Ink.graphite, s * .025f, seed, closed = true, wobble = s * .01f, sharp = true)
            inkStroke(listOf(Offset(c.x - w * .6f, c.y - h * .5f), Offset(c.x - w * .2f, c.y - h * .2f)), Ink.blue, s * .03f, seed + 1, passes = 1, wobble = s * .005f, sharp = true)
            inkStroke(listOf(Offset(c.x + w * .0f, c.y - h * .2f), Offset(c.x - w * .35f, c.y - h * .5f)), Ink.blue, s * .03f, seed + 2, passes = 1, wobble = s * .005f, sharp = true)
            drawCircle(Ink.blue, radius = s * .03f, center = Offset(c.x - w * .45f, c.y - h * .05f))
            drawCircle(Ink.blue, radius = s * .03f, center = Offset(c.x - w * .1f, c.y - h * .05f))
        }
        else -> {
            inkStroke(circlePts(c, s * .4f, 12), Ink.graphite, s * .025f, seed, closed = true, wobble = s * .01f)
        }
    }
}

/** The path badge: the four inks wear their print colours, the four ways of undoing wear their own. */
@Composable
fun PathBadge(path: BPath?, size: Dp = 22.dp) {
    if (path == null) return
    val (bg, fg) = when (path) {
        BPath.C -> Color(0xFF00AEEF) to Ink.blue
        BPath.M -> Color(0xFFEC008C) to Color.White
        BPath.Y -> Color(0xFFFFF200) to Ink.blue
        BPath.K -> Color(0xFF26262B) to Color.White
        BPath.Eraser -> Color(0xFFF2A7A4) to Ink.blue
        BPath.Correction -> Color(0xFFC8322A) to Color.White
        BPath.Friction -> Color(0xFFE8833A) to Ink.blue
        BPath.Scribble -> Color(0xFF8A8F98) to Color.White
    }
    Box(Modifier.size(size).sketchBox(path.ordinal + 7, bg, Ink.blue, radius = size / 2, width = 1.2.dp), contentAlignment = Alignment.Center) {
        Text(path.badge, style = hand(if (size >= 22.dp) 12 else 10, fg))
    }
}

/** Small green up-arrow when the acting hero has the edge, red down-arrow when the enemy does. */
@Composable
fun MatchupArrow(matchup: Int) {
    if (matchup == 0) return
    val up = matchup > 0
    val col = if (up) Color(0xFF2E7D32) else Ink.red
    Canvas(Modifier.size(12.dp)) {
        val pts = if (up) listOf(Offset(size.width / 2, 0f), Offset(size.width, size.height), Offset(0f, size.height))
        else listOf(Offset(0f, 0f), Offset(size.width, 0f), Offset(size.width / 2, size.height))
        drawPath(sharpPath(pts, true), color = col)
    }
}
