package com.nibgame.app.data

import android.content.Context
import com.nibgame.app.Config
import com.nibgame.app.battle.BattleData
import com.nibgame.app.battle.BattleParser
import com.nibgame.app.engine.Cast
import com.nibgame.app.engine.Manifest
import com.nibgame.app.engine.SCHEMA_SUPPORTED
import com.nibgame.app.engine.StoryParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** A complete set of story files, wherever they came from. */
class Pack(val manifest: Manifest, val cast: Cast, val data: BattleData, val read: (String) -> String)

sealed interface UpdateResult {
    data object UpToDate : UpdateResult
    data class Updated(val newChapterTitles: List<String>) : UpdateResult
    data object NeedsAppUpdate : UpdateResult
    data class Failed(val reason: String) : UpdateResult
}

/**
 * Story files ship inside the app (assets/content) and can be replaced by newer ones from GitHub.
 * Only JSON text is ever downloaded, never code, which is what keeps this inside Google Play's rules.
 */
class ContentRepo(private val context: Context) {
    private val localDir = File(context.filesDir, "content")

    private fun pack(read: (String) -> String): Pack {
        val manifest = StoryParser.manifest(read("manifest.json"))
        return Pack(manifest, StoryParser.cast(read(manifest.cast)), BattleParser.parse(read(manifest.data)), read)
    }

    /** Uses the downloaded set if it is newer than the one inside the app, otherwise the bundled one. */
    fun load(): Pack {
        val bundled = pack { name -> context.assets.open("content/$name").bufferedReader().use { it.readText() } }
        val downloaded = runCatching { pack { name -> File(localDir, name).readText() } }.getOrNull()
        val useDownloaded = downloaded != null &&
            downloaded.manifest.version > bundled.manifest.version &&
            downloaded.manifest.schema <= SCHEMA_SUPPORTED
        return if (useDownloaded) downloaded!! else bundled
    }

    suspend fun checkForUpdate(): UpdateResult = withContext(Dispatchers.IO) {
        try {
            val current = load().manifest
            val remoteText = http(Config.CONTENT_BASE_URL + "manifest.json")
            val remote = StoryParser.manifest(remoteText)
            if (remote.schema > SCHEMA_SUPPORTED) return@withContext UpdateResult.NeedsAppUpdate
            if (remote.version <= current.version) return@withContext UpdateResult.UpToDate

            // Build the new set in a scratch folder first.
            val staging = File(context.filesDir, "content_tmp")
            staging.deleteRecursively()
            staging.mkdirs()
            val have = runCatching { StoryParser.manifest(File(localDir, "manifest.json").readText()) }.getOrNull()
            for (info in remote.chapters) {
                val existing = File(localDir, info.file)
                val unchanged = have?.chapters?.any { it.id == info.id && it.rev == info.rev } == true
                if (unchanged && existing.exists()) {
                    existing.copyTo(File(staging, info.file))
                } else {
                    File(staging, info.file).writeText(http(Config.CONTENT_BASE_URL + info.file))
                }
            }
            File(staging, remote.cast).writeText(http(Config.CONTENT_BASE_URL + remote.cast))
            File(staging, remote.data).writeText(http(Config.CONTENT_BASE_URL + remote.data))
            File(staging, "manifest.json").writeText(remoteText)

            // Everything must parse before it is allowed to replace what the player already has.
            val staged = pack { File(staging, it).readText() }
            staged.manifest.chapters.forEach { StoryParser.chapter(staged.read(it.file)) }

            val backup = File(context.filesDir, "content_old")
            backup.deleteRecursively()
            if (localDir.exists() && !localDir.renameTo(backup)) throw IOException("Couldn't replace the old story files")
            if (!staging.renameTo(localDir)) {
                backup.renameTo(localDir)
                throw IOException("Couldn't install the new story files")
            }
            backup.deleteRecursively()

            val known = current.chapters.map { it.id }.toSet()
            UpdateResult.Updated(remote.chapters.filter { it.id !in known }.map { it.title })
        } catch (e: Exception) {
            UpdateResult.Failed(e.message ?: e.javaClass.simpleName)
        }
    }

    private fun http(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            if (c.responseCode != 200) throw IOException("HTTP ${c.responseCode} for ${url.substringAfterLast('/')}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }
}
