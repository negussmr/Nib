# Nib: chat-story engine (Day 1)

A phone-chat story engine for Android (Kotlin + Jetpack Compose). Branching conversations,
typing indicators, save/resume, **no skip**, a hand-drawn notebook look, and story updates
pulled from GitHub as JSON. No art files: the stickmen are drawn in code.

## Build it from your phone (GitHub builds the APK for you)

1. On github.com make a new **public** repository (say `nib`) and tick "Add a README".
2. Add file -> Create new file. In the name box type `.github/workflows/build.yml`
   and paste the contents of `build.yml` from this zip (it is also in the chat). Commit.
3. Add file -> Upload files -> choose `nib-engine.zip` (this zip, as is, do not unzip it). Commit.
4. Open the Actions tab. The first build takes about 8 to 10 minutes. Green tick = done.
5. Open the run, then the link in its Summary (or the repo's Releases page),
   tap `nib-debug.apk` and install it. Allow your browser to install unknown apps if asked.
   If Play Protect warns about an unknown app, choose "Install anyway".

Every later version of the game is just a new zip uploaded to the same repo. Each build is
installed over the last one and keeps your save.

If a build fails (red cross): open the run, scroll to the Summary, copy the "Build failed"
box and send it to Claude.

The first build also copies the story files into a `content/` folder in your repo. That
folder is what the game downloads monthly updates from. The build fills in your repo name
automatically, so there is nothing to configure.

Prefer a computer? Android Studio works too: open this folder as a project.

Requirements: Android 8.0 or newer (minSdk 26). Targets Android 16 (API 36), which Google Play
requires for new apps.

## What is where

| Folder | Job |
|---|---|
| `engine/` | Pure Kotlin. Story format, parser, the step-by-step runner, save file. Tested without a phone. |
| `data/ContentRepo.kt` | Loads story files from the app, or newer ones downloaded from GitHub. |
| `StoryViewModel.kt` | Plays a chapter at reading pace, keeps the save in step with the screen. |
| `ui/` | Notebook paper, pen-drawn bubbles, stickman avatars, chat and chapter list. |
| `Config.kt` | How often to check for updates, reading pace, game title. |
| `assets/content/` | The story that ships inside the app. |
| `update-example/` | A fake "month 2" update (chapter 2) for testing the GitHub flow. |
| `ci/build.sh`, `build.yml` | What GitHub runs to build the APK. `build.gradle.kts`, `app/build.gradle.kts` are the normal Android build files. |

## Monthly story updates

1. Your repo's `content/` folder already exists after the first build (public repo needed).
2. Test it: in GitHub, open `content/manifest.json`, replace it with `update-example/manifest.json`
   from this zip, and add `update-example/ch02.json` as `content/ch02.json` (Add file ->
   Create new file, paste the text). Then open the game and tap "Check for new chapters".
   Chapter 2 appears after chapter 1 is finished.

Every month: add `ch03.json`, add it to `manifest.json`, **raise `version`**, push.
Players get it the next time they open the app (checks at most every 12 hours).

Safety built in: a download is parsed and checked in a scratch folder first and only replaces
the old story if every file is valid. A typo in your JSON can never break an installed game.
If you add a brand-new kind of step, raise `schema` in the manifest and `SCHEMA_SUPPORTED`
in `engine/Model.kt`. Old app versions then show "update the app" instead of choking.

**Rule for released chapters:** fix typos freely, but never add, remove or reorder steps in a
chapter players may be halfway through. Their save points at a step number.

## Writing a chapter

A chapter is a list of steps. Steps run top to bottom.

| Step | Example | Does |
|---|---|---|
| say | `{"say":"pica","text":"hi"}` | A message. `"typing":1800` overrides the typing time. |
| narr | `{"narr":"3:12 AM."}` | A caption in the middle of the page. |
| choice | `{"choice":[{"text":"Hi","goto":"a"}]}` | Reply buttons. Options take `goto`, `set`, `if`, `once`. |
| label | `{"label":"a"}` | A place to jump to. |
| goto | `{"goto":"a"}` | Jump. |
| set | `{"set":["trust+=1","met=1"]}` | Change variables (`=`, `+=`, `-=`). Remembered across chapters. |
| if | `{"if":"trust>=2","goto":"a"}` | Jump if true, otherwise carry on. |
| wait | `{"wait":1400}` | A silent beat, in milliseconds. |
| give | `{"give":"id","name":"Lamppost Glow","note":"..."}` | Shows an item card and sets `has_id=1`. |
| end | `{"end":true}` | Finishes the chapter. |

Conditions: `x`, `!x`, `x>=2`, `x==0`, joined with `&&`. Unset variables are 0.
`"once":true` on a choice option hides it after it is picked (good for ask-about-things menus).
The player's own lines are `say` steps from the player character (`"player"` in `cast.json`).
They show on the right, in highlighter yellow.

## Characters and look

`cast.json` sets each character's name, pen colour (`ink`), and which stickman (`avatar`).
Built-in avatars: `nib`, `pica`, `hatch`, `mystery`. Anything else gets a plain stickman.
To draw a new one, add a case in `ui/Avatar.kt`. It is about ten lines of pen strokes.

The font is Handlee (SIL Open Font License, see `FONT_LICENSE.txt`).

## Honest limits of Day 1

- The engine logic is tested (300 playthroughs, resume from every saved step, broken-chapter
  rejection), and so is the build script. The Compose UI and the Gradle build could not be
  compiled where this was written, so the first GitHub build may fail with a few errors.
  Send the "Build failed" box and they are quick to fix.
- Google Play does not allow an app to update its own code from GitHub. Story JSON is fine
  (it is data). Code updates go through Play.
